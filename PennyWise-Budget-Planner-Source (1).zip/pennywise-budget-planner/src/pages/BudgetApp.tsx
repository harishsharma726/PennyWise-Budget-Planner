import React, { useState, useEffect, useRef } from 'react';
import {
  Wallet, List, LayoutGrid, Settings, Target,
  Calculator as TaxIcon, FileDown, Plus, X, MoreVertical, Pencil, Trash2,
  BarChart3, CalendarRange
} from 'lucide-react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger
} from '@/components/ui/dropdown-menu';
import { MoreHorizontal } from 'lucide-react';

import {
  Transaction, CURRENCIES, BUDGET_CATEGORIES, DEFAULT_SETTINGS,
  AppSettings, DashboardMetric, Category
} from '@/types';
import {
  loadTransactions, saveTransactions, loadCurrency, saveCurrency,
  loadHouseholdExpense, saveHouseholdExpense, loadSettings, saveSettings
} from '@/lib/storage';
import { TransactionForm } from '@/components/TransactionForm';
import { BudgetSummary } from '@/components/BudgetSummary';
import { MonthlyCharts } from '@/components/MonthlyCharts';
import { TransactionList } from '@/components/TransactionList';
import { BudgetPlan } from '@/components/BudgetPlan';
import { TaxCalculator } from '@/components/TaxCalculator';
import { Reports } from '@/components/Reports';
import { CustomizationSidebar } from '@/components/CustomizationSidebar';
import { ExpenseForecasting } from '@/components/ExpenseForecasting';

// ── helpers ──────────────────────────────────────────────────────────────────
const GROUP_COLORS: Record<string, string> = {
  income: '#10b981',
  expense: '#f43f5e',
  savings: '#6366f1',
  liability: '#f59e0b',
};

function randomColor() {
  return '#' + Math.floor(Math.random() * 0xffffff).toString(16).padStart(6, '0');
}

// ── inline edit state type ───────────────────────────────────────────────────
interface EditingCat {
  index: number;
  name: string;
  group: Category['group'];
}

// ── live clock hook ───────────────────────────────────────────────────────────
function useLiveClock() {
  const [now, setNow] = useState(new Date());
  const ref = useRef<ReturnType<typeof setInterval> | null>(null);
  useEffect(() => {
    ref.current = setInterval(() => setNow(new Date()), 1000);
    return () => { if (ref.current) clearInterval(ref.current); };
  }, []);
  return now;
}

// ── plan period label helpers ─────────────────────────────────────────────────
const MONTH_NAMES = [
  'January','February','March','April','May','June',
  'July','August','September','October','November','December',
];

function getPlanPeriodLabel(filter: {
  mode: 'monthly' | 'quarterly' | 'yearly';
  year: number;
  month: number;
  quarter: string;
}) {
  if (filter.mode === 'monthly') {
    return `${MONTH_NAMES[filter.month]} ${filter.year}`;
  }
  if (filter.mode === 'quarterly') {
    const fyEnd = (filter.year + 1).toString().slice(2);
    return `${filter.quarter} · FY ${filter.year}–${fyEnd}`;
  }
  const fyEnd = (filter.year + 1).toString().slice(2);
  return `FY ${filter.year}–${fyEnd}`;
}

// ── PlanPeriodBanner ──────────────────────────────────────────────────────────
function PlanPeriodBanner({ filter }: {
  filter: { mode: 'monthly' | 'quarterly' | 'yearly'; year: number; month: number; quarter: string };
}) {
  const now = useLiveClock();

  const dayOfWeek   = now.toLocaleDateString('en-US', { weekday: 'long' });
  const dayNum      = now.getDate();
  const monthName   = now.toLocaleDateString('en-US', { month: 'long' });
  const fullYear    = now.getFullYear();
  const timeStr     = now.toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false });
  const periodLabel = getPlanPeriodLabel(filter);

  return (
    <div className="bg-gradient-to-r from-indigo-700 via-indigo-600 to-indigo-500
                    rounded-2xl shadow-lg shadow-indigo-500/25 overflow-hidden shrink-0">
      {/* top row — full width date + clock strip */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2
                      px-6 pt-4 pb-3 border-b border-white/10">
        {/* Big date block */}
        <div className="flex items-center gap-4">
          {/* Day number pill */}
          <div className="flex flex-col items-center justify-center w-14 h-14 rounded-2xl
                          bg-white/15 backdrop-blur-sm border border-white/20 shrink-0">
            <span className="text-2xl font-black text-white leading-none">{dayNum}</span>
            <span className="text-[9px] font-black uppercase tracking-widest text-indigo-200 leading-none mt-0.5">
              {monthName.slice(0, 3)}
            </span>
          </div>
          <div>
            <p className="text-[10px] font-black uppercase tracking-widest text-indigo-300">Today</p>
            <p className="text-xl font-black text-white leading-tight">{dayOfWeek}</p>
            <p className="text-sm font-bold text-indigo-200 leading-tight">
              {monthName} {dayNum}, {fullYear}
            </p>
          </div>
        </div>

        {/* Live clock */}
        <div className="sm:text-right">
          <p className="text-[10px] font-black uppercase tracking-widest text-indigo-300">Current time</p>
          <p className="text-3xl font-black text-white font-mono tracking-widest tabular-nums">{timeStr}</p>
        </div>
      </div>

      {/* bottom row — planning period */}
      <div className="flex items-center gap-3 px-6 py-3">
        <div className="w-7 h-7 rounded-lg bg-white/15 flex items-center justify-center shrink-0">
          <Target className="w-3.5 h-3.5 text-white" />
        </div>
        <div>
          <p className="text-[9px] font-black uppercase tracking-widest text-indigo-300">Planning period</p>
          <p className="text-base font-black text-white leading-tight">{periodLabel}</p>
        </div>
      </div>
    </div>
  );
}

// ── component ────────────────────────────────────────────────────────────────
export default function BudgetApp() {
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [activeTab, setActiveTab] = useState<'overview' | 'history' | 'plan' | 'tax' | 'reports'>('overview');
  const [planSubTab, setPlanSubTab] = useState<'tracker' | 'forecast'>('tracker');
  const [currencyCode, setCurrencyCode] = useState('INR');
  const [householdExpense, setHouseholdExpense] = useState(0);
  const [settings, setSettings] = useState<AppSettings>(DEFAULT_SETTINGS);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isCustomizing, setIsCustomizing] = useState(false);

  // new-category form
  const [newCatName, setNewCatName] = useState('');
  const [newCatGroup, setNewCatGroup] = useState<Category['group']>('expense');

  // inline edit state
  const [editingCat, setEditingCat] = useState<EditingCat | null>(null);

  const [dashboardFilter, setDashboardFilter] = useState({
    mode: 'monthly' as 'monthly' | 'quarterly' | 'yearly',
    year: new Date().getMonth() < 3 ? new Date().getFullYear() - 1 : new Date().getFullYear(),
    month: new Date().getMonth(),
    quarter: ('Q' + (Math.floor(((new Date().getMonth() + 9) % 12) / 3) + 1)) as 'Q1' | 'Q2' | 'Q3' | 'Q4',
  });

  // ── load / save ─────────────────────────────────────────────────────────
  useEffect(() => {
    setTransactions(loadTransactions());
    setCurrencyCode(loadCurrency());
    setHouseholdExpense(loadHouseholdExpense());
    const loaded = loadSettings();
    if (loaded && typeof loaded === 'object' && 'theme' in (loaded as object)) {
      const ls = loaded as Partial<AppSettings>;
      setSettings(prev => ({
        ...DEFAULT_SETTINGS,
        ...ls,
        salaryFormulas: { ...DEFAULT_SETTINGS.salaryFormulas, ...(ls.salaryFormulas || {}) },
        allManagedCategories: (ls as AppSettings).allManagedCategories ?? null,
      }));
    }
  }, []);

  useEffect(() => { saveSettings(settings); }, [settings]);
  useEffect(() => { saveTransactions(transactions); }, [transactions]);
  useEffect(() => { saveCurrency(currencyCode); }, [currencyCode]);
  useEffect(() => { saveHouseholdExpense(householdExpense); }, [householdExpense]);

  // ── derived: allCategories ───────────────────────────────────────────────
  // If allManagedCategories has never been set, derive from BUDGET_CATEGORIES + customCategories.
  // Once the user edits/deletes anything we store the full list in allManagedCategories.
  const allCategories: Category[] =
    settings.allManagedCategories ??
    [...BUDGET_CATEGORIES, ...(settings.customCategories || [])];

  /** Replace allManagedCategories with a new list */
  const setAllCategories = (cats: Category[]) => {
    setSettings(s => ({ ...s, allManagedCategories: cats }));
  };

  // ── category CRUD ────────────────────────────────────────────────────────
  const handleAddCategory = () => {
    if (!newCatName.trim()) return;
    const newCat: Category = {
      name: newCatName.trim(),
      group: newCatGroup,
      color: GROUP_COLORS[newCatGroup] ?? randomColor(),
      icon: 'plus-circle',
    };
    setAllCategories([...allCategories, newCat]);
    // Keep customCategories in sync for TransactionForm compatibility
    setSettings(s => ({
      ...s,
      customCategories: [...(s.customCategories || []), newCat],
      allManagedCategories: [...allCategories, newCat],
    }));
    setNewCatName('');
  };

  const handleSaveEdit = () => {
    if (!editingCat || !editingCat.name.trim()) return;
    const updated = allCategories.map((c, i) =>
      i === editingCat.index ? { ...c, name: editingCat.name.trim(), group: editingCat.group } : c
    );
    setAllCategories(updated);
    setEditingCat(null);
  };

  const handleDeleteCategory = (index: number) => {
    setAllCategories(allCategories.filter((_, i) => i !== index));
  };

  // ── currency ─────────────────────────────────────────────────────────────
  const currentCurrency = CURRENCIES.find(c => c.code === currencyCode) || CURRENCIES[0];

  // ── filter transactions ──────────────────────────────────────────────────
  const getFilteredTransactions = () => {
    return transactions.filter(t => {
      const date = new Date(t.date);
      const year = date.getFullYear();
      const month = date.getMonth();
      if (dashboardFilter.mode === 'yearly') {
        return date >= new Date(dashboardFilter.year, 3, 1) &&
               date <= new Date(dashboardFilter.year + 1, 2, 31, 23, 59, 59);
      }
      if (dashboardFilter.mode === 'quarterly') {
        const fyYear = dashboardFilter.year;
        let qMonths: number[] = [];
        let qYear = fyYear;
        if (dashboardFilter.quarter === 'Q1') qMonths = [3, 4, 5];
        if (dashboardFilter.quarter === 'Q2') qMonths = [6, 7, 8];
        if (dashboardFilter.quarter === 'Q3') qMonths = [9, 10, 11];
        if (dashboardFilter.quarter === 'Q4') { qMonths = [0, 1, 2]; qYear = fyYear + 1; }
        return qMonths.includes(month) && year === qYear;
      }
      return month === dashboardFilter.month && year === dashboardFilter.year;
    });
  };

  const filteredTransactions = getFilteredTransactions();

  // ── transaction handlers ─────────────────────────────────────────────────
  const handleAddTransaction = (t: Omit<Transaction, 'id'>) =>
    setTransactions(prev => [...prev, { ...t, id: crypto.randomUUID() }]);

  const handleDeleteTransaction = (id: string) =>
    setTransactions(prev => prev.filter(t => t.id !== id));

  // ── salary calc ──────────────────────────────────────────────────────────
  const netSalaryResult = React.useMemo(() => {
    const ctc = settings.totalCTC;
    const f = settings.salaryFormulas;
    const basicAnnual = Math.round(ctc * (f.basicPct / 100));
    const hraAnnual = Math.round(basicAnnual * (f.hraPct / 100));
    const specialAnnual = Math.round(ctc * (f.specialAllowancePct / 100));
    const pfAnnual = Math.round(basicAnnual * (f.pfPct / 100));
    const criticalAnnual = settings.criticalIllness * 12;
    const exGratiaAnnual = settings.exGratia * 12;
    const monthlyGross = (basicAnnual + hraAnnual + specialAnnual +
      Math.max(0, ctc - (basicAnnual + hraAnnual + specialAnnual + pfAnnual + criticalAnnual + exGratiaAnnual))) / 12;
    const chargeableIncome = Math.max(0, monthlyGross * 12 - 75000);
    let tax = 0;
    [
      { min: 400000, max: 800000, rate: 0.05 },
      { min: 800000, max: 1200000, rate: 0.10 },
      { min: 1200000, max: 1600000, rate: 0.15 },
      { min: 1600000, max: 2000000, rate: 0.20 },
      { min: 2000000, max: 2400000, rate: 0.25 },
      { min: 2400000, max: Infinity, rate: 0.30 },
    ].forEach(s => { tax += Math.max(0, Math.min(chargeableIncome, s.max) - s.min) * s.rate; });
    return monthlyGross - Math.round(pfAnnual / 12) - (tax * 1.04) / 12;
  }, [settings.totalCTC, settings.salaryFormulas, settings.criticalIllness, settings.exGratia]);

  // ── summary values ───────────────────────────────────────────────────────
  const totalIncomeActual =
    filteredTransactions.filter(t => t.type === 'income').reduce((a, t) => a + t.amount, 0);
  const totalExpenseActual =
    filteredTransactions.filter(t => t.type === 'expense').reduce((a, t) => a + t.amount, 0);
  const netSavings = totalIncomeActual - totalExpenseActual - householdExpense;
  const savingsRate = totalIncomeActual > 0 ? Math.max(0, (netSavings / totalIncomeActual) * 100) : 0;

  // ── rich dashboard components ────────────────────────────────────────────
  const renderRichComponent = (type: DashboardMetric['type']): React.ReactNode => {
    switch (type) {
      case 'charts':
        return <MonthlyCharts transactions={filteredTransactions} currencySymbol={currentCurrency.symbol} hideHeader />;
      case 'transaction-list':
        return <TransactionList transactions={filteredTransactions} onDeleteTransaction={handleDeleteTransaction} currencySymbol={currentCurrency.symbol} limit={8} hideHeader />;
      case 'budget-plan':
        return <BudgetPlan transactions={filteredTransactions} currencySymbol={currentCurrency.symbol} householdExpense={householdExpense} netSalary={netSalaryResult} hideHeader />;
      case 'balance-card':
        return (
          <div className="p-6 bg-indigo-600 text-white flex flex-col justify-between h-full overflow-hidden relative">
            <h2 className="text-4xl font-black relative z-10">
              {currentCurrency.symbol}{filteredTransactions.reduce((a, t) => a + (t.type === 'income' ? t.amount : -t.amount), 0).toLocaleString()}
            </h2>
            <div className="absolute right-[-20px] bottom-[-20px] opacity-10">
              <Wallet className="w-32 h-32" />
            </div>
          </div>
        );
      case 'health-score':
        return (
          <div className="p-6 bg-emerald-50 border border-emerald-100 h-full flex flex-col justify-center">
            <div className="flex items-center gap-2">
              <Target className="w-4 h-4 text-emerald-500" />
              <span className="text-sm font-bold text-slate-800">Financial Freedom</span>
            </div>
            <div className="mt-2 flex items-baseline gap-1">
              <span className="text-2xl font-black text-emerald-600">{savingsRate.toFixed(1)}%</span>
              <span className="text-[10px] text-slate-400 font-bold uppercase">Savings Rate</span>
            </div>
            <p className="text-[10px] text-slate-500 mt-2">
              {savingsRate > 30 ? 'Excellent velocity!' : savingsRate > 15 ? 'Steady building.' : 'Focus on savings.'}
            </p>
          </div>
        );
      default:
        return null;
    }
  };

  const dashboardMetrics = settings.dashboardMetrics.filter(m =>
    activeTab === 'plan'
      ? ['total-income', 'investments', 'cc-expense', 'total-expense', 'budget-plan'].includes(m.type)
      : m.type !== 'budget-plan'
  );

  const handleUpdateMetric = (updated: DashboardMetric) =>
    setSettings(s => ({ ...s, dashboardMetrics: s.dashboardMetrics.map(m => m.id === updated.id ? updated : m) }));
  const handleDeleteMetric = (id: string) =>
    setSettings(s => ({ ...s, dashboardMetrics: s.dashboardMetrics.filter(m => m.id !== id) }));
  const handleAddMetric = (nm: DashboardMetric) =>
    setSettings(s => ({ ...s, dashboardMetrics: [...s.dashboardMetrics, nm] }));
  const handleReorderMetrics = (metrics: DashboardMetric[]) =>
    setSettings(s => ({ ...s, dashboardMetrics: metrics }));
  const handleUpdatePageTitle = (key: string, title: string) =>
    setSettings(s => ({ ...s, pageTitles: { ...s.pageTitles, [key]: title } }));

  const getUserInitials = (name: string) =>
    name.split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2);

  const isDark = settings.theme === 'dark' || settings.theme === 'midnight';

  // ── render ───────────────────────────────────────────────────────────────
  return (
    <div className={`min-h-screen py-4 px-4 md:px-8 font-sans transition-all duration-700 flex flex-col relative overflow-hidden ${isDark ? 'bg-slate-950' : 'bg-slate-50'}`}>
      {(settings.theme === 'frosted' || settings.theme === 'glass') && (
        <>
          <div className="mesh-gradient-1" />
          <div className="mesh-gradient-2" />
        </>
      )}

      {/* Main Window Frame */}
      <div className={`max-w-[1600px] w-full mx-auto h-[calc(100vh-2rem)] rounded-3xl overflow-hidden flex flex-col shadow-2xl transition-all duration-500 border ${isDark ? 'bg-slate-900/80 border-slate-800' : 'bg-white/30 backdrop-blur-xl border-white/50'}`}>

        {/* Title Bar */}
        <div className={`h-12 flex items-center justify-between px-6 border-b transition-colors shrink-0 ${isDark ? 'bg-slate-950/50 border-slate-800' : 'bg-white/20 backdrop-blur-md border-white/20'}`}>
          <div className="flex items-center gap-2">
            <div className="flex gap-1.5 grayscale opacity-50">
              <div className="w-3 h-2.5 bg-red-400 rounded-full" />
              <div className="w-3 h-2.5 bg-yellow-400 rounded-full" />
              <div className="w-3 h-2.5 bg-green-400 rounded-full" />
            </div>
            <span className={`ml-4 text-sm font-semibold tracking-tight ${isDark ? 'text-slate-300' : 'text-slate-700'}`}>
              {settings.appName}
            </span>
          </div>

          <div className="flex items-center gap-3">
            {/* Currency selector */}
            <Select value={currencyCode} onValueChange={setCurrencyCode}>
              <SelectTrigger className={`w-[80px] h-8 rounded-lg text-[10px] font-bold border-none ${isDark ? 'bg-slate-800 text-slate-300' : 'bg-white/40 text-slate-700 shadow-sm'}`}>
                <SelectValue />
              </SelectTrigger>
              <SelectContent className={isDark ? 'bg-slate-900 border-slate-800 text-slate-300' : 'bg-white/90 backdrop-blur-xl border-white/40 shadow-2xl'}>
                {CURRENCIES.map(c => (
                  <SelectItem key={c.code} value={c.code} className="text-[10px] font-bold">{c.code} ({c.symbol})</SelectItem>
                ))}
              </SelectContent>
            </Select>

            {/* Grid customization */}
            <Button variant="ghost" size="icon" onClick={() => setIsCustomizing(true)}
              className={`h-8 w-8 hover:bg-white/30 ${isDark ? 'text-slate-400' : 'text-slate-500'}`}>
              <LayoutGrid className="w-4 h-4" />
            </Button>

            {/* ── Settings Dialog ── */}
            <Dialog open={isSettingsOpen} onOpenChange={open => { setIsSettingsOpen(open); if (!open) setEditingCat(null); }}>
              <DialogTrigger asChild>
                <Button variant="ghost" size="icon"
                  className={`h-8 w-8 hover:bg-white/30 ${isDark ? 'text-slate-400' : 'text-slate-500'}`}>
                  <Settings className="w-4 h-4" />
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-lg max-h-[88vh] overflow-y-auto rounded-3xl p-0 gap-0">
                {/* Header */}
                <div className="px-6 pt-6 pb-4 border-b border-slate-100">
                  <DialogHeader>
                    <DialogTitle className="text-xl font-black tracking-tight">Personalization Hub</DialogTitle>
                  </DialogHeader>
                  <p className="text-xs text-slate-500 font-medium mt-1">Configure your workspace and preferences.</p>
                </div>

                <div className="px-6 py-6 space-y-8">
                  {/* Identity */}
                  <section className="space-y-4">
                    <Label className="text-[10px] font-black uppercase text-indigo-500 tracking-widest">Identity & Branding</Label>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label className="text-[11px] font-bold opacity-70">Display Name</Label>
                        <Input value={settings.userName} onChange={e => setSettings(s => ({ ...s, userName: e.target.value }))} className="h-10 rounded-xl" />
                      </div>
                      <div className="space-y-2">
                        <Label className="text-[11px] font-bold opacity-70">Workspace Name</Label>
                        <Input value={settings.appName} onChange={e => setSettings(s => ({ ...s, appName: e.target.value }))} className="h-10 rounded-xl" />
                      </div>
                    </div>
                  </section>

                  {/* Theme */}
                  <section className="space-y-4">
                    <Label className="text-[10px] font-black uppercase text-indigo-500 tracking-widest">Visual Architecture</Label>
                    <div className="grid grid-cols-3 gap-2">
                      {(['glass', 'frosted', 'minimalist', 'warm', 'dark', 'midnight'] as const).map(t => (
                        <button key={t} onClick={() => setSettings(s => ({ ...s, theme: t }))}
                          className={`h-16 rounded-2xl border-2 transition-all flex flex-col items-center justify-center gap-1 ${settings.theme === t ? 'border-indigo-500 bg-indigo-50' : 'border-slate-100 hover:border-slate-300 bg-slate-50/50'}`}>
                          <div className={`w-6 h-6 rounded-full ${t === 'glass' ? 'bg-white/40 border border-slate-200' : t === 'frosted' ? 'bg-indigo-100' : t === 'minimalist' ? 'bg-slate-50 border' : t === 'warm' ? 'bg-orange-100' : t === 'dark' ? 'bg-slate-800' : 'bg-slate-950'}`} />
                          <span className="text-[10px] font-black uppercase tracking-tighter text-slate-500">{t}</span>
                        </button>
                      ))}
                    </div>
                  </section>

                  {/* ── Category Management ── */}
                  <section className="space-y-4">
                    <div className="flex items-center justify-between">
                      <Label className="text-[10px] font-black uppercase text-indigo-500 tracking-widest">Expense Categories</Label>
                      <span className="text-[9px] font-bold text-slate-400 bg-slate-100 px-2 py-0.5 rounded-full uppercase">
                        {allCategories.length} total
                      </span>
                    </div>

                    {/* Category list */}
                    <div className="space-y-1.5 max-h-72 overflow-y-auto pr-1">
                      {allCategories.map((cat, idx) => (
                        <div key={idx}>
                          {/* ── View row ── */}
                          {editingCat?.index !== idx ? (
                            <div className="flex items-center justify-between px-3 py-2.5 bg-white/50 backdrop-blur-sm rounded-xl border border-white/60 hover:bg-white/70 transition-colors group">
                              <div className="flex items-center gap-3 min-w-0">
                                <div className="w-7 h-7 rounded-lg flex items-center justify-center shrink-0"
                                  style={{ backgroundColor: cat.color + '22', border: `1.5px solid ${cat.color}55` }}>
                                  <div className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: cat.color }} />
                                </div>
                                <div className="min-w-0">
                                  <p className="text-xs font-bold text-slate-800 truncate">{cat.name}</p>
                                  <p className="text-[9px] uppercase tracking-wider font-black"
                                    style={{ color: GROUP_COLORS[cat.group] ?? '#94a3b8' }}>
                                    {cat.group}
                                  </p>
                                </div>
                              </div>

                              {/* Three-dot menu — ALL categories */}
                              <DropdownMenu>
                                <DropdownMenuTrigger asChild>
                                  <Button variant="ghost" size="icon"
                                    className="h-7 w-7 shrink-0 text-slate-300 hover:text-slate-600 hover:bg-white opacity-0 group-hover:opacity-100 transition-opacity">
                                    <MoreVertical className="w-3.5 h-3.5" />
                                  </Button>
                                </DropdownMenuTrigger>
                                <DropdownMenuContent align="end" className="w-36 rounded-xl shadow-xl border-white/40">
                                  <DropdownMenuItem
                                    className="text-xs font-medium gap-2 cursor-pointer"
                                    onSelect={() => setEditingCat({ index: idx, name: cat.name, group: cat.group })}>
                                    <Pencil className="w-3.5 h-3.5 text-indigo-500" />
                                    Edit
                                  </DropdownMenuItem>
                                  <DropdownMenuItem
                                    className="text-xs font-medium gap-2 cursor-pointer text-rose-600 focus:text-rose-600"
                                    onSelect={() => handleDeleteCategory(idx)}>
                                    <Trash2 className="w-3.5 h-3.5" />
                                    Delete
                                  </DropdownMenuItem>
                                </DropdownMenuContent>
                              </DropdownMenu>
                            </div>
                          ) : (
                            /* ── Inline edit row ── */
                            <div className="px-3 py-3 bg-indigo-50 rounded-xl border border-indigo-200 space-y-2">
                              <div className="flex gap-2">
                                <Input
                                  autoFocus
                                  value={editingCat.name}
                                  onChange={e => setEditingCat(ec => ec ? { ...ec, name: e.target.value } : ec)}
                                  onKeyDown={e => { if (e.key === 'Enter') handleSaveEdit(); if (e.key === 'Escape') setEditingCat(null); }}
                                  className="h-8 text-xs flex-1 rounded-lg bg-white border-indigo-200"
                                />
                                <Select
                                  value={editingCat.group}
                                  onValueChange={v => setEditingCat(ec => ec ? { ...ec, group: v as Category['group'] } : ec)}>
                                  <SelectTrigger className="w-[110px] h-8 text-[10px] font-bold rounded-lg bg-white border-indigo-200">
                                    <SelectValue />
                                  </SelectTrigger>
                                  <SelectContent>
                                    <SelectItem value="expense" className="text-[10px] font-bold">Expense</SelectItem>
                                    <SelectItem value="savings" className="text-[10px] font-bold">Savings</SelectItem>
                                    <SelectItem value="income" className="text-[10px] font-bold">Income</SelectItem>
                                    <SelectItem value="liability" className="text-[10px] font-bold">Liability</SelectItem>
                                  </SelectContent>
                                </Select>
                              </div>
                              <div className="flex gap-2 justify-end">
                                <Button size="sm" variant="ghost" onClick={() => setEditingCat(null)}
                                  className="h-7 text-[10px] px-3 rounded-lg text-slate-500">
                                  Cancel
                                </Button>
                                <Button size="sm" onClick={handleSaveEdit}
                                  className="h-7 text-[10px] px-3 rounded-lg bg-indigo-600 text-white hover:bg-indigo-700">
                                  Save
                                </Button>
                              </div>
                            </div>
                          )}
                        </div>
                      ))}
                    </div>

                    {/* Add new category */}
                    <div className="p-4 bg-indigo-50/60 rounded-2xl border border-dashed border-indigo-200">
                      <Label className="text-[10px] font-black text-indigo-600 uppercase mb-3 block">Add Category</Label>
                      <div className="flex gap-2">
                        <Input
                          value={newCatName}
                          onChange={e => setNewCatName(e.target.value)}
                          onKeyDown={e => { if (e.key === 'Enter') handleAddCategory(); }}
                          placeholder="Category name…"
                          className="h-9 text-xs flex-1 rounded-xl bg-white border-0 shadow-sm"
                        />
                        <Select value={newCatGroup} onValueChange={(v: any) => setNewCatGroup(v)}>
                          <SelectTrigger className="w-[110px] h-9 text-[10px] font-bold rounded-xl bg-white border-0 shadow-sm">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="expense" className="text-[10px] font-bold">Expense</SelectItem>
                            <SelectItem value="savings" className="text-[10px] font-bold">Savings</SelectItem>
                            <SelectItem value="income" className="text-[10px] font-bold">Income</SelectItem>
                            <SelectItem value="liability" className="text-[10px] font-bold">Liability</SelectItem>
                          </SelectContent>
                        </Select>
                        <Button onClick={handleAddCategory}
                          className="h-9 px-3 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl shadow-md shadow-indigo-200">
                          <Plus className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  </section>

                  {/* Salary formulas */}
                  <section className="space-y-3 pb-2">
                    <Label className="text-[10px] font-black uppercase text-indigo-500 tracking-widest">Salary Structure Formulas (%)</Label>
                    <div className="grid grid-cols-2 gap-4">
                      {[
                        { id: 'basicPct', label: 'Basic % of CTC', key: 'basicPct' as const, step: '0.0001' },
                        { id: 'hraPct', label: 'HRA % of Basic', key: 'hraPct' as const, step: '0.01' },
                        { id: 'specialPct', label: 'Special Allowance %', key: 'specialAllowancePct' as const, step: '0.0001' },
                        { id: 'pfPct', label: 'PF % of Basic', key: 'pfPct' as const, step: '0.1' },
                      ].map(({ id, label, key, step }) => (
                        <div key={id} className="space-y-2">
                          <Label htmlFor={id} className="text-[11px] font-bold opacity-70">{label}</Label>
                          <Input id={id} type="number" step={step}
                            value={settings.salaryFormulas[key]}
                            onChange={e => setSettings(s => ({ ...s, salaryFormulas: { ...s.salaryFormulas, [key]: parseFloat(e.target.value) || 0 } }))}
                            className="rounded-xl font-mono text-sm" />
                        </div>
                      ))}
                    </div>
                    <p className="text-[10px] text-slate-400 italic">Conveyance is automatically calculated as the balancing figure.</p>
                  </section>
                </div>

                <DialogFooter className="px-6 pb-6">
                  <Button onClick={() => { setIsSettingsOpen(false); setEditingCat(null); }}
                    className="bg-indigo-600 text-white rounded-xl w-full">
                    Done
                  </Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>

            {/* Avatar */}
            <div className="w-8 h-8 rounded-lg bg-indigo-600 flex items-center justify-center text-white text-[10px] font-bold shadow-lg shadow-indigo-500/20">
              {getUserInitials(settings.userName)}
            </div>
          </div>
        </div>

        {/* Body */}
        <div className="flex flex-1 overflow-hidden">
          {/* Sidebar */}
          <aside className={`w-64 hidden lg:flex flex-col p-6 gap-6 shrink-0 ${isDark ? 'bg-slate-900 border-r border-slate-800' : 'glass-sidebar'}`}>
            <nav className="flex flex-col gap-2">
              {([
                { tab: 'overview', icon: <LayoutGrid className="w-5 h-5" />, key: 'overview' },
                { tab: 'plan',     icon: <Target className="w-5 h-5" />,     key: 'plan' },
                { tab: 'tax',      icon: <TaxIcon className="w-5 h-5" />,    key: 'tax' },
                { tab: 'reports',  icon: <FileDown className="w-5 h-5" />,   key: 'reports' },
                { tab: 'history',  icon: <List className="w-5 h-5" />,       key: 'history' },
              ] as const).map(({ tab, icon, key }) => (
                <SidebarItem key={tab} icon={icon} label={settings.pageTitles[key]}
                  active={activeTab === tab} onClick={() => setActiveTab(tab)} isDark={isDark} />
              ))}
            </nav>
          </aside>

          {/* Main content */}
          <main className="flex-1 overflow-y-auto p-4 md:p-8 min-w-0">
            <div className="max-w-[1240px] mx-auto space-y-8">
              {/* Page header */}
              <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6 mb-8">
                <div className="flex flex-col gap-1 min-w-0">
                  <div className="flex items-center gap-3">
                    <h1 className="text-3xl font-black text-slate-800 tracking-tight text-balance">
                      {settings.pageTitles[activeTab]}
                    </h1>
                    <Popover>
                      <PopoverTrigger className="h-8 w-8 rounded-full hover:bg-white/50 inline-flex items-center justify-center text-slate-400 hover:text-slate-600 transition-colors cursor-pointer outline-none">
                        <MoreHorizontal className="w-4 h-4" />
                      </PopoverTrigger>
                      <PopoverContent className="w-64 p-3 rounded-2xl" align="start">
                        <div className="space-y-3">
                          <Label className="text-xs font-black uppercase text-slate-400 tracking-widest">Edit Page Name</Label>
                          <Input defaultValue={settings.pageTitles[activeTab]}
                            onBlur={e => handleUpdatePageTitle(activeTab, e.target.value)}
                            className="rounded-xl h-9 text-sm" />
                        </div>
                      </PopoverContent>
                    </Popover>
                  </div>
                  <p className="text-sm font-medium text-slate-500 text-pretty">
                    {activeTab === 'overview' && 'Your comprehensive financial summary and analytics.'}
                    {activeTab === 'plan' && 'Plan your savings and track your monthly budget.'}
                    {activeTab === 'tax' && 'Detailed breakup of your salary and tax liability (FY 2024-25).'}
                    {activeTab === 'reports' && 'Export professional financial statements.'}
                    {activeTab === 'history' && 'Manage and review every transaction.'}
                  </p>
                </div>

                {activeTab === 'overview' && (
                  <div className="flex flex-wrap items-center gap-3 bg-white/40 p-2 rounded-2xl border border-white/60 shadow-sm shrink-0">
                    <div className="flex bg-white/50 rounded-xl p-1 border border-white/40">
                      {(['monthly', 'quarterly', 'yearly'] as const).map(mode => (
                        <button key={mode} onClick={() => setDashboardFilter(f => ({ ...f, mode }))}
                          className={`px-4 py-2 rounded-lg text-[10px] font-black uppercase tracking-wider transition-all ${dashboardFilter.mode === mode ? 'bg-indigo-600 text-white shadow-md' : 'text-slate-500 hover:bg-white/50'}`}>
                          {mode}
                        </button>
                      ))}
                    </div>
                    <div className="flex items-center gap-2">
                      <Select value={dashboardFilter.year.toString()} onValueChange={v => setDashboardFilter(f => ({ ...f, year: parseInt(v) }))}>
                        <SelectTrigger className="w-[100px] h-10 rounded-xl text-xs font-bold bg-white/50"><SelectValue /></SelectTrigger>
                        <SelectContent>
                          {[2023, 2024, 2025, 2026].map(y => (
                            <SelectItem key={y} value={y.toString()} className="text-xs font-bold">FY {y}-{(y + 1).toString().slice(2)}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      {dashboardFilter.mode === 'monthly' && (
                        <Select value={dashboardFilter.month.toString()} onValueChange={v => setDashboardFilter(f => ({ ...f, month: parseInt(v) }))}>
                          <SelectTrigger className="w-[120px] h-10 rounded-xl text-xs font-bold bg-white/50">
                            <SelectValue>{['January','February','March','April','May','June','July','August','September','October','November','December'][dashboardFilter.month]}</SelectValue>
                          </SelectTrigger>
                          <SelectContent>
                            {['January','February','March','April','May','June','July','August','September','October','November','December'].map((m, i) => (
                              <SelectItem key={m} value={i.toString()} className="text-xs font-bold">{m}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      )}
                      {dashboardFilter.mode === 'quarterly' && (
                        <Select value={dashboardFilter.quarter} onValueChange={(v: any) => setDashboardFilter(f => ({ ...f, quarter: v }))}>
                          <SelectTrigger className="w-[80px] h-10 rounded-xl text-xs font-bold bg-white/50"><SelectValue /></SelectTrigger>
                          <SelectContent>
                            {['Q1','Q2','Q3','Q4'].map(q => <SelectItem key={q} value={q} className="text-xs font-bold">{q}</SelectItem>)}
                          </SelectContent>
                        </Select>
                      )}
                    </div>
                  </div>
                )}
              </div>

              {(activeTab === 'overview' || activeTab === 'plan') && (
                <BudgetSummary transactions={filteredTransactions} currencySymbol={currentCurrency.symbol}
                  householdExpense={householdExpense} netSalary={netSalaryResult}
                  metrics={dashboardMetrics} onUpdateMetric={handleUpdateMetric}
                  onDeleteMetric={handleDeleteMetric} onReorderMetrics={handleReorderMetrics}
                  renderRichComponent={renderRichComponent} />
              )}

              {activeTab === 'overview' && (
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                  <MonthlyCharts transactions={filteredTransactions} currencySymbol={currentCurrency.symbol} />
                  <TransactionList transactions={filteredTransactions} onDeleteTransaction={handleDeleteTransaction} currencySymbol={currentCurrency.symbol} limit={8} />
                </div>
              )}

              {activeTab === 'plan' && (
                <div className="space-y-6">
                  <PlanPeriodBanner filter={dashboardFilter} />

                  {/* ── sub-tab switcher ── */}
                  <div className="flex gap-1 p-1 bg-white/40 backdrop-blur-sm rounded-xl border border-white/60 w-fit">
                    {([
                      { key: 'tracker', label: 'Monthly Tracker', icon: <CalendarRange className="w-3.5 h-3.5" /> },
                      { key: 'forecast', label: 'Expense Forecasting', icon: <BarChart3 className="w-3.5 h-3.5" /> },
                    ] as const).map(t => (
                      <button key={t.key} onClick={() => setPlanSubTab(t.key)}
                        className={`flex items-center gap-1.5 px-4 py-2 rounded-lg text-xs font-black uppercase tracking-wider transition-all ${
                          planSubTab === t.key
                            ? 'bg-indigo-600 text-white shadow-md'
                            : 'text-slate-500 hover:bg-white/60'
                        }`}>
                        {t.icon}{t.label}
                      </button>
                    ))}
                  </div>

                  {planSubTab === 'tracker' && (
                    <BudgetPlan transactions={filteredTransactions} currencySymbol={currentCurrency.symbol} householdExpense={householdExpense} netSalary={netSalaryResult} />
                  )}
                  {planSubTab === 'forecast' && (
                    <ExpenseForecasting netSalary={netSalaryResult} currencySymbol={currentCurrency.symbol} />
                  )}
                </div>
              )}

              {activeTab === 'tax' && (
                <TaxCalculator currencySymbol={currentCurrency.symbol} formulas={settings.salaryFormulas}
                  totalPackage={settings.totalCTC} criticalIllness={settings.criticalIllness} exGratia={settings.exGratia}
                  onUpdateTotalPackage={val => setSettings(s => ({ ...s, totalCTC: val }))}
                  onUpdateDeductions={(field, val) => setSettings(s => ({ ...s, [field]: val }))} />
              )}

              {activeTab === 'reports' && (
                <Reports transactions={filteredTransactions} currencySymbol={currentCurrency.symbol} />
              )}

              {activeTab === 'history' && (
                <TransactionList transactions={transactions} onDeleteTransaction={handleDeleteTransaction} currencySymbol={currentCurrency.symbol} />
              )}
            </div>
          </main>
        </div>
      </div>

      {/* FAB */}
      <TransactionForm onAddTransaction={handleAddTransaction} householdExpense={householdExpense}
        onUpdateHouseholdExpense={setHouseholdExpense} currencySymbol={currentCurrency.symbol}
        customCategories={allCategories} />

      <CustomizationSidebar isOpen={isCustomizing} onClose={() => setIsCustomizing(false)}
        metrics={settings.dashboardMetrics} onAddMetric={handleAddMetric} />

      {/* Mobile bottom nav */}
      <div className="lg:hidden fixed bottom-6 left-1/2 -translate-x-1/2 glass-panel px-6 py-3 rounded-2xl flex items-center gap-6 shadow-xl z-40">
        {([
          { tab: 'overview', icon: <LayoutGrid className="w-5 h-5" /> },
          { tab: 'plan',     icon: <Target className="w-5 h-5" /> },
          { tab: 'tax',      icon: <TaxIcon className="w-5 h-5" /> },
          { tab: 'reports',  icon: <FileDown className="w-5 h-5" /> },
          { tab: 'history',  icon: <List className="w-5 h-5" /> },
        ] as const).map(({ tab, icon }) => (
          <button key={tab} onClick={() => setActiveTab(tab)}
            className={activeTab === tab ? 'text-indigo-600' : 'text-slate-400'}>
            {icon}
          </button>
        ))}
      </div>
    </div>
  );
}

function SidebarItem({ icon, label, active, onClick, isDark }: {
  icon: React.ReactNode; label: string; active: boolean; onClick: () => void; isDark?: boolean;
}) {
  return (
    <button onClick={onClick}
      className={`flex items-center gap-3 px-4 py-3 rounded-xl transition-all font-medium text-sm w-full
        ${active
          ? isDark ? 'bg-slate-700 text-white' : 'bg-white/40 text-indigo-700 shadow-sm border border-white/50'
          : isDark ? 'text-slate-400 hover:bg-slate-800' : 'text-slate-600 hover:bg-white/20'}`}>
      {icon}{label}
    </button>
  );
}
