import React, { useState, useEffect, useRef } from 'react';
import * as XLSX from 'xlsx';
import {
  Plus, Trash2, Pencil, Upload, ChevronDown, ChevronUp,
  TrendingDown, TrendingUp, Wallet, PiggyBank, AlertCircle, X, Check
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter
} from '@/components/ui/dialog';
import {
  ForecastItem, ForecastCategory,
  FORECAST_CATEGORY_LABELS, FORECAST_CATEGORY_COLORS
} from '@/types';
import { loadForecastItems, saveForecastItems } from '@/lib/storage';

// ── helpers ──────────────────────────────────────────────────────────────────
const MONTH_NAMES = [
  'January', 'February', 'March', 'April', 'May', 'June',
  'July', 'August', 'September', 'October', 'November', 'December',
];

function getNext6Months(): { key: string; label: string; short: string }[] {
  const result = [];
  const now = new Date();
  for (let i = 0; i < 6; i++) {
    const d = new Date(now.getFullYear(), now.getMonth() + i, 1);
    const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
    const label = `${MONTH_NAMES[d.getMonth()]} ${d.getFullYear()}`;
    const short = `${MONTH_NAMES[d.getMonth()].slice(0, 3)} ${d.getFullYear()}`;
    result.push({ key, label, short });
  }
  return result;
}

function fmt(amount: number, symbol: string) {
  return `${symbol}${Math.abs(amount).toLocaleString('en-IN', { maximumFractionDigits: 0 })}`;
}

const CATEGORIES: ForecastCategory[] = [
  'credit-card', 'rent', 'emi', 'utility', 'savings', 'insurance', 'groceries', 'other',
];

const EMPTY_FORM: Omit<ForecastItem, 'id'> = {
  name: '',
  amount: 0,
  category: 'other',
  month: '',
  note: '',
};

// ── props ─────────────────────────────────────────────────────────────────────
interface ExpenseForecastingProps {
  netSalary: number;
  currencySymbol: string;
}

// ── component ────────────────────────────────────────────────────────────────
export function ExpenseForecasting({ netSalary, currencySymbol }: ExpenseForecastingProps) {
  const months = getNext6Months();

  const [items, setItems] = useState<ForecastItem[]>([]);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState<Omit<ForecastItem, 'id'>>({ ...EMPTY_FORM, month: months[0].key });
  const [editId, setEditId] = useState<string | null>(null);
  const [expandedMonth, setExpandedMonth] = useState<string | null>(months[0].key);
  const [importError, setImportError] = useState('');
  const [importSuccess, setImportSuccess] = useState('');
  const [formError, setFormError] = useState('');
  const fileRef = useRef<HTMLInputElement>(null);

  // load from localStorage
  useEffect(() => {
    setItems(loadForecastItems());
  }, []);

  // save on change
  useEffect(() => {
    saveForecastItems(items);
  }, [items]);

  // ── form helpers ────────────────────────────────────────────────────────
  const resetForm = () => {
    setForm({ ...EMPTY_FORM, month: months[0].key });
    setEditId(null);
    setFormError('');
  };

  const openAdd = () => { resetForm(); setShowForm(true); };

  const openEdit = (item: ForecastItem) => {
    setForm({ name: item.name, amount: item.amount, category: item.category, month: item.month, note: item.note ?? '' });
    setEditId(item.id);
    setShowForm(true);
  };

  const handleSave = () => {
    if (!form.name.trim()) { setFormError('Name is required.'); return; }
    if (!form.amount || form.amount <= 0) { setFormError('Amount must be greater than 0.'); return; }
    if (!form.month) { setFormError('Please select a month.'); return; }
    setFormError('');

    if (editId) {
      setItems(prev => prev.map(i => i.id === editId ? { ...form, id: editId } : i));
    } else {
      setItems(prev => [...prev, { ...form, id: crypto.randomUUID() }]);
    }
    setShowForm(false);
    resetForm();
    setExpandedMonth(form.month);
  };

  const handleDelete = (id: string) => {
    setItems(prev => prev.filter(i => i.id !== id));
  };

  // ── Excel import ────────────────────────────────────────────────────────
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    setImportError('');
    setImportSuccess('');
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (ev) => {
      try {
        const data = new Uint8Array(ev.target!.result as ArrayBuffer);
        const wb = XLSX.read(data, { type: 'array' });
        const ws = wb.Sheets[wb.SheetNames[0]];
        const rows: Record<string, unknown>[] = XLSX.utils.sheet_to_json(ws, { defval: '' });

        const valid: ForecastItem[] = [];
        const errors: string[] = [];

        rows.forEach((row, idx) => {
          const name = String(row['Name'] ?? row['name'] ?? '').trim();
          const amtRaw = row['Amount'] ?? row['amount'] ?? 0;
          const amount = parseFloat(String(amtRaw));
          const catRaw = String(row['Category'] ?? row['category'] ?? 'other').toLowerCase().replace(/\s+/g, '-');
          const monthRaw = String(row['Month'] ?? row['month'] ?? '').trim();

          if (!name) { errors.push(`Row ${idx + 2}: missing Name`); return; }
          if (isNaN(amount) || amount <= 0) { errors.push(`Row ${idx + 2}: invalid Amount`); return; }

          // parse month: accepts "YYYY-MM", "Mon YYYY", "Month YYYY"
          let monthKey = '';
          if (/^\d{4}-\d{2}$/.test(monthRaw)) {
            monthKey = monthRaw;
          } else {
            const parsed = new Date(`1 ${monthRaw}`);
            if (!isNaN(parsed.getTime())) {
              monthKey = `${parsed.getFullYear()}-${String(parsed.getMonth() + 1).padStart(2, '0')}`;
            }
          }
          if (!monthKey) { errors.push(`Row ${idx + 2}: unreadable Month "${monthRaw}" (use "YYYY-MM" or "Jan 2025")`); return; }

          const category: ForecastCategory = CATEGORIES.includes(catRaw as ForecastCategory)
            ? (catRaw as ForecastCategory)
            : 'other';

          valid.push({ id: crypto.randomUUID(), name, amount, category, month: monthKey, note: String(row['Note'] ?? row['note'] ?? '') });
        });

        if (errors.length) {
          setImportError(`Import issues:\n${errors.join('\n')}`);
        }
        if (valid.length) {
          setItems(prev => [...prev, ...valid]);
          setImportSuccess(`Imported ${valid.length} item${valid.length > 1 ? 's' : ''} successfully.`);
        }
      } catch {
        setImportError('Could not read the file. Ensure it is a valid .xlsx or .xls file.');
      }
    };
    reader.readAsArrayBuffer(file);
    // reset input so same file can be re-uploaded
    e.target.value = '';
  };

  // ── per-month aggregation ────────────────────────────────────────────────
  const monthSummary = (monthKey: string) => {
    const monthItems = items.filter(i => i.month === monthKey);
    const totalExpense = monthItems
      .filter(i => i.category !== 'savings')
      .reduce((a, i) => a + i.amount, 0);
    const totalSavings = monthItems
      .filter(i => i.category === 'savings')
      .reduce((a, i) => a + i.amount, 0);
    const remaining = netSalary - totalExpense - totalSavings;
    return { monthItems, totalExpense, totalSavings, remaining };
  };

  const totalAcrossAll = items.reduce((a, i) => a + (i.category !== 'savings' ? i.amount : 0), 0);
  const totalSavingsAll = items.reduce((a, i) => a + (i.category === 'savings' ? i.amount : 0), 0);

  // ── render ───────────────────────────────────────────────────────────────
  return (
    <div className="space-y-6">
      {/* ── Top summary strip ── */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {[
          { label: '6-Month Expenses', value: fmt(totalAcrossAll, currencySymbol), icon: <TrendingDown className="w-4 h-4" />, color: 'text-rose-500', bg: 'bg-rose-50' },
          { label: '6-Month Savings', value: fmt(totalSavingsAll, currencySymbol), icon: <PiggyBank className="w-4 h-4" />, color: 'text-emerald-500', bg: 'bg-emerald-50' },
          { label: 'Monthly Income', value: netSalary > 0 ? fmt(netSalary, currencySymbol) : 'Not set', icon: <TrendingUp className="w-4 h-4" />, color: 'text-indigo-500', bg: 'bg-indigo-50' },
          { label: 'Avg. Monthly Left', value: netSalary > 0 ? fmt(netSalary - totalAcrossAll / 6 - totalSavingsAll / 6, currencySymbol) : '–', icon: <Wallet className="w-4 h-4" />, color: 'text-amber-500', bg: 'bg-amber-50' },
        ].map(s => (
          <div key={s.label} className={`flex items-center gap-3 p-4 rounded-2xl ${s.bg} border border-white/60`}>
            <div className={`${s.color} shrink-0`}>{s.icon}</div>
            <div className="min-w-0">
              <p className="text-[10px] font-black uppercase tracking-widest text-slate-400 truncate">{s.label}</p>
              <p className={`text-lg font-black ${s.color} truncate`}>{s.value}</p>
            </div>
          </div>
        ))}
      </div>

      {/* ── Actions row ── */}
      <div className="flex flex-wrap gap-3 items-center justify-between">
        <div className="flex gap-2 flex-wrap">
          <Button onClick={openAdd}
            className="bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl gap-2 shadow-md shadow-indigo-200">
            <Plus className="w-4 h-4" /> Add Expense
          </Button>
          <Button variant="outline" onClick={() => fileRef.current?.click()}
            className="rounded-xl gap-2 border-indigo-200 text-indigo-600 hover:bg-indigo-50">
            <Upload className="w-4 h-4" /> Import Excel
          </Button>
          <input ref={fileRef} type="file" accept=".xlsx,.xls" className="hidden" onChange={handleFileUpload} />
        </div>
        <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">
          {items.length} item{items.length !== 1 ? 's' : ''} across 6 months
        </p>
      </div>

      {/* import messages */}
      {importError && (
        <div className="flex gap-2 p-3 bg-rose-50 border border-rose-200 rounded-xl text-xs text-rose-700 whitespace-pre-wrap">
          <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />{importError}
        </div>
      )}
      {importSuccess && (
        <div className="flex gap-2 p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-xs text-emerald-700">
          <Check className="w-4 h-4 shrink-0" />{importSuccess}
        </div>
      )}

      {/* Excel template hint */}
      <div className="px-4 py-3 bg-slate-50 border border-dashed border-slate-200 rounded-xl">
        <p className="text-[10px] font-bold text-slate-500">
          <span className="text-indigo-600 font-black">Excel format:</span> Columns →{' '}
          <code className="bg-white px-1 rounded">Name</code>{' '}
          <code className="bg-white px-1 rounded">Amount</code>{' '}
          <code className="bg-white px-1 rounded">Category</code>{' '}
          <code className="bg-white px-1 rounded">Month</code>{' '}
          <code className="bg-white px-1 rounded">Note</code>{' '}
          — Month format: <code className="bg-white px-1 rounded">2025-06</code> or <code className="bg-white px-1 rounded">Jun 2025</code>
          . Category values: {CATEGORIES.join(', ')}.
        </p>
      </div>

      {/* ── 6-month cards ── */}
      <div className="space-y-4">
        {months.map(m => {
          const { monthItems, totalExpense, totalSavings, remaining } = monthSummary(m.key);
          const isOpen = expandedMonth === m.key;
          const usedPct = netSalary > 0 ? Math.min(100, ((totalExpense + totalSavings) / netSalary) * 100) : 0;

          return (
            <Card key={m.key} className="rounded-2xl border-white/60 bg-white/50 backdrop-blur-sm shadow-sm overflow-hidden">
              {/* month header */}
              <button
                className="w-full flex items-center justify-between px-5 py-4 hover:bg-white/60 transition-colors"
                onClick={() => setExpandedMonth(isOpen ? null : m.key)}>
                <div className="flex items-center gap-4 min-w-0">
                  <div className="w-10 h-10 rounded-xl bg-indigo-600 flex items-center justify-center shrink-0 shadow-md shadow-indigo-200">
                    <span className="text-[10px] font-black text-white uppercase">{m.short.slice(0, 3)}</span>
                  </div>
                  <div className="min-w-0 text-left">
                    <p className="text-sm font-black text-slate-800">{m.label}</p>
                    <p className="text-[10px] text-slate-400 font-bold">
                      {monthItems.length} item{monthItems.length !== 1 ? 's' : ''}
                      {netSalary > 0 && (
                        <> &nbsp;·&nbsp;
                          <span className={remaining >= 0 ? 'text-emerald-500' : 'text-rose-500'}>
                            {remaining >= 0 ? '+' : ''}{fmt(remaining, currencySymbol)} remaining
                          </span>
                        </>
                      )}
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-6 shrink-0">
                  <div className="hidden md:flex gap-6 text-right">
                    <div>
                      <p className="text-[9px] font-black uppercase text-slate-400">Expenses</p>
                      <p className="text-sm font-black text-rose-500">{fmt(totalExpense, currencySymbol)}</p>
                    </div>
                    <div>
                      <p className="text-[9px] font-black uppercase text-slate-400">Savings</p>
                      <p className="text-sm font-black text-emerald-500">{fmt(totalSavings, currencySymbol)}</p>
                    </div>
                    {netSalary > 0 && (
                      <div>
                        <p className="text-[9px] font-black uppercase text-slate-400">Remaining</p>
                        <p className={`text-sm font-black ${remaining >= 0 ? 'text-indigo-600' : 'text-rose-600'}`}>
                          {fmt(remaining, currencySymbol)}
                        </p>
                      </div>
                    )}
                  </div>
                  {isOpen ? <ChevronUp className="w-4 h-4 text-slate-400" /> : <ChevronDown className="w-4 h-4 text-slate-400" />}
                </div>
              </button>

              {/* usage bar */}
              {netSalary > 0 && monthItems.length > 0 && (
                <div className="px-5 pb-2">
                  <Progress value={usedPct} className="h-1.5 bg-slate-100" />
                </div>
              )}

              {/* expanded body */}
              {isOpen && (
                <CardContent className="px-5 pb-5 pt-2 space-y-3">
                  {/* mobile summary */}
                  <div className="flex md:hidden gap-3 text-xs font-bold">
                    <span className="text-rose-500">Exp: {fmt(totalExpense, currencySymbol)}</span>
                    <span className="text-emerald-500">Sav: {fmt(totalSavings, currencySymbol)}</span>
                    {netSalary > 0 && <span className={remaining >= 0 ? 'text-indigo-600' : 'text-rose-600'}>Left: {fmt(remaining, currencySymbol)}</span>}
                  </div>

                  {monthItems.length === 0 ? (
                    <div className="flex flex-col items-center py-8 gap-2">
                      <Wallet className="w-8 h-8 text-slate-200" />
                      <p className="text-xs font-bold text-slate-400">No items yet for {m.label}</p>
                      <Button size="sm" variant="outline" onClick={() => { setForm({ ...EMPTY_FORM, month: m.key }); setShowForm(true); }}
                        className="mt-1 rounded-xl border-indigo-200 text-indigo-600 hover:bg-indigo-50 gap-1 text-xs">
                        <Plus className="w-3 h-3" /> Add item
                      </Button>
                    </div>
                  ) : (
                    <div className="space-y-2">
                      {monthItems.map(item => (
                        <div key={item.id}
                          className="flex items-center justify-between gap-3 px-3 py-2.5 bg-white/70 rounded-xl border border-white/60 hover:bg-white transition-colors">
                          <div className="flex items-center gap-3 min-w-0">
                            <div className="w-2 h-8 rounded-full shrink-0"
                              style={{ backgroundColor: FORECAST_CATEGORY_COLORS[item.category] }} />
                            <div className="min-w-0">
                              <p className="text-xs font-bold text-slate-800 truncate">{item.name}</p>
                              <div className="flex items-center gap-1.5 mt-0.5 flex-wrap">
                                <Badge variant="secondary"
                                  style={{ backgroundColor: FORECAST_CATEGORY_COLORS[item.category] + '22', color: FORECAST_CATEGORY_COLORS[item.category], borderColor: FORECAST_CATEGORY_COLORS[item.category] + '44' }}
                                  className="text-[9px] font-black uppercase px-1.5 py-0 border">
                                  {FORECAST_CATEGORY_LABELS[item.category]}
                                </Badge>
                                {item.note && <span className="text-[10px] text-slate-400 truncate max-w-[120px]">{item.note}</span>}
                              </div>
                            </div>
                          </div>
                          <div className="flex items-center gap-2 shrink-0">
                            <span className={`text-sm font-black ${item.category === 'savings' ? 'text-emerald-600' : 'text-slate-800'}`}>
                              {fmt(item.amount, currencySymbol)}
                            </span>
                            <Button variant="ghost" size="icon" onClick={() => openEdit(item)}
                              className="h-7 w-7 text-slate-300 hover:text-indigo-600 hover:bg-indigo-50">
                              <Pencil className="w-3.5 h-3.5" />
                            </Button>
                            <Button variant="ghost" size="icon" onClick={() => handleDelete(item.id)}
                              className="h-7 w-7 text-slate-300 hover:text-rose-600 hover:bg-rose-50">
                              <Trash2 className="w-3.5 h-3.5" />
                            </Button>
                          </div>
                        </div>
                      ))}

                      {/* Add more button at bottom */}
                      <button onClick={() => { setForm({ ...EMPTY_FORM, month: m.key }); setShowForm(true); }}
                        className="w-full flex items-center justify-center gap-1.5 py-2 text-[10px] font-black uppercase tracking-widest text-indigo-400 hover:text-indigo-600 border border-dashed border-indigo-200 rounded-xl hover:bg-indigo-50 transition-colors">
                        <Plus className="w-3.5 h-3.5" /> Add to {m.short}
                      </button>
                    </div>
                  )}
                </CardContent>
              )}
            </Card>
          );
        })}
      </div>

      {/* ── Add / Edit Dialog ── */}
      <Dialog open={showForm} onOpenChange={open => { if (!open) { setShowForm(false); resetForm(); } }}>
        <DialogContent className="max-w-[calc(100%-2rem)] md:max-w-md rounded-3xl">
          <DialogHeader>
            <DialogTitle className="text-lg font-black">{editId ? 'Edit Forecast Item' : 'Add Forecast Item'}</DialogTitle>
          </DialogHeader>

          <div className="space-y-4 py-2">
            {/* Name */}
            <div className="space-y-1.5">
              <Label className="text-xs font-bold text-slate-600">Name / Description</Label>
              <Input value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))}
                placeholder="e.g. HDFC Credit Card Bill, SBI Home EMI…"
                className="rounded-xl" />
            </div>

            {/* Amount */}
            <div className="space-y-1.5">
              <Label className="text-xs font-bold text-slate-600">Amount ({currencySymbol})</Label>
              <Input type="number" min="0" value={form.amount || ''}
                onChange={e => setForm(f => ({ ...f, amount: parseFloat(e.target.value) || 0 }))}
                placeholder="0"
                className="rounded-xl font-mono" />
            </div>

            {/* Category + Month row */}
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label className="text-xs font-bold text-slate-600">Category</Label>
                <Select value={form.category} onValueChange={v => setForm(f => ({ ...f, category: v as ForecastCategory }))}>
                  <SelectTrigger className="rounded-xl text-xs"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {CATEGORIES.map(c => (
                      <SelectItem key={c} value={c} className="text-xs font-bold">
                        <span className="flex items-center gap-2">
                          <span className="w-2 h-2 rounded-full shrink-0 inline-block" style={{ backgroundColor: FORECAST_CATEGORY_COLORS[c] }} />
                          {FORECAST_CATEGORY_LABELS[c]}
                        </span>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs font-bold text-slate-600">Month</Label>
                <Select value={form.month} onValueChange={v => setForm(f => ({ ...f, month: v }))}>
                  <SelectTrigger className="rounded-xl text-xs"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {getNext6Months().map(m => (
                      <SelectItem key={m.key} value={m.key} className="text-xs font-bold">{m.label}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            {/* Note */}
            <div className="space-y-1.5">
              <Label className="text-xs font-bold text-slate-600">Note (optional)</Label>
              <Input value={form.note ?? ''} onChange={e => setForm(f => ({ ...f, note: e.target.value }))}
                placeholder="e.g. Annual renewal, partial payment…"
                className="rounded-xl" />
            </div>

            {formError && (
              <div className="flex items-center gap-2 text-xs text-rose-600 bg-rose-50 px-3 py-2 rounded-xl">
                <AlertCircle className="w-3.5 h-3.5 shrink-0" />{formError}
              </div>
            )}
          </div>

          <DialogFooter className="gap-2 flex-col sm:flex-row">
            <Button variant="outline" onClick={() => { setShowForm(false); resetForm(); }} className="rounded-xl flex-1">
              <X className="w-4 h-4 mr-1" /> Cancel
            </Button>
            <Button onClick={handleSave} className="bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl flex-1">
              <Check className="w-4 h-4 mr-1" /> {editId ? 'Save Changes' : 'Add Item'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
