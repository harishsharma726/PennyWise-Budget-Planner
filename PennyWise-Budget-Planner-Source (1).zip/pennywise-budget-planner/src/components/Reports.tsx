/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Card, CardHeader, CardTitle, CardContent, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { FileDown, FileSpreadsheet, FileText, Download, CheckCircle2 } from 'lucide-react';
import { Transaction } from '../types';
import * as XLSX from 'xlsx';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';

interface ReportsProps {
  transactions: Transaction[];
  currencySymbol: string;
}

type ReportType = 'pl_monthly' | 'pl_annual' | 'balance_sheet' | 'income_statement';
type ExportFormat = 'excel' | 'pdf';

export function Reports({ transactions, currencySymbol }: ReportsProps) {
  const [reportType, setReportType] = useState<ReportType>('pl_monthly');
  const [exportFormat, setExportFormat] = useState<ExportFormat>('pdf');
  const [isGenerating, setIsGenerating] = useState(false);

  const generateReport = () => {
    setIsGenerating(true);
    
    // Simulate generation delay
    setTimeout(() => {
      try {
        if (exportFormat === 'excel') {
          exportToExcel();
        } else {
          exportToPDF();
        }
      } catch (error) {
        console.error('Export failed:', error);
      } finally {
        setIsGenerating(false);
      }
    }, 1000);
  };

  const getReportData = () => {
    // Basic data extraction for reports
    const income = transactions.filter(t => t.type === 'income');
    const expenses = transactions.filter(t => t.type === 'expense');
    
    const totalIncome = income.reduce((sum, t) => sum + t.amount, 0);
    const totalExpense = expenses.reduce((sum, t) => sum + t.amount, 0);
    const netProfit = totalIncome - totalExpense;

    return { income, expenses, totalIncome, totalExpense, netProfit };
  };

  const exportToExcel = () => {
    const { income, expenses, totalIncome, totalExpense, netProfit } = getReportData();
    
    const wb = XLSX.utils.book_new();
    
    // Transactions Sheet
    const wsData = transactions.map(t => ({
      Date: t.date,
      Type: t.type.toUpperCase(),
      Category: t.category,
      Description: t.description,
      Amount: t.amount
    }));
    const ws = XLSX.utils.json_to_sheet(wsData);
    XLSX.utils.book_append_sheet(wb, ws, "Transactions");

    // Summary Sheet
    const summaryData = [
      ["Financial Report Summary"],
      ["Report Type", reportType.replace('_', ' ').toUpperCase()],
      [],
      ["Metric", "Value"],
      ["Total Income", totalIncome],
      ["Total Expenses", totalExpense],
      ["Net Profit/Loss", netProfit]
    ];
    const wsSummary = XLSX.utils.aoa_to_sheet(summaryData);
    XLSX.utils.book_append_sheet(wb, wsSummary, "Summary");

    XLSX.writeFile(wb, `PennyWise_Report_${reportType}.xlsx`);
  };

  const exportToPDF = () => {
    const { income, expenses, totalIncome, totalExpense, netProfit } = getReportData();
    const doc = new jsPDF();

    doc.setFontSize(20);
    doc.text("PennyWise Financial Report", 14, 22);
    
    doc.setFontSize(12);
    doc.text(`Type: ${reportType.replace('_', ' ').toUpperCase()}`, 14, 32);
    doc.text(`Generated on: ${new Date().toLocaleDateString()}`, 14, 40);

    // Summary Table
    autoTable(doc, {
      startY: 50,
      head: [['Category', 'Amount']],
      body: [
        ['Total Income', `${currencySymbol}${totalIncome.toLocaleString()}`],
        ['Total Expenses', `${currencySymbol}${totalExpense.toLocaleString()}`],
        ['Net Savings/Surplus', `${currencySymbol}${netProfit.toLocaleString()}`],
      ],
      theme: 'striped',
      headStyles: { fillStyle: [99, 102, 241] } as any
    });

    // Detailed Transactions
    doc.addPage();
    doc.text("Detailed Transaction History", 14, 22);
    
    autoTable(doc, {
      startY: 30,
      head: [['Date', 'Type', 'Category', 'Description', 'Amount']],
      body: transactions.map(t => [
        t.date,
        t.type.toUpperCase(),
        t.category,
        t.description,
        `${currencySymbol}${t.amount.toLocaleString()}`
      ]),
      styles: { fontSize: 8 }
    });

    doc.save(`PennyWise_Report_${reportType}.pdf`);
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card className="glass-card overflow-hidden">
          <CardHeader className="bg-indigo-50/50 border-b border-indigo-100/50">
            <CardTitle className="text-xl font-bold text-indigo-700 flex items-center gap-2">
              <FileText className="w-5 h-5" />
              Report Configuration
            </CardTitle>
          </CardHeader>
          <CardContent className="p-6 space-y-6">
            <div className="space-y-2">
              <label className="text-xs font-bold text-slate-500 uppercase">Select Report Type</label>
              <Select value={reportType} onValueChange={(v: any) => setReportType(v)}>
                <SelectTrigger className="rounded-xl h-12">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="pl_monthly">Monthly P&L Statement</SelectItem>
                  <SelectItem value="pl_annual">Annual P&L Statement</SelectItem>
                  <SelectItem value="balance_sheet">Personal Balance Sheet</SelectItem>
                  <SelectItem value="income_statement">Consolidated Income Statement</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-4">
              <label className="text-xs font-bold text-slate-500 uppercase">Export Format</label>
              <div className="grid grid-cols-2 gap-3">
                <button 
                  onClick={() => setExportFormat('pdf')}
                  className={`flex items-center justify-center gap-2 p-4 rounded-2xl border-2 transition-all ${exportFormat === 'pdf' ? 'border-red-500 bg-red-50 text-red-700' : 'border-slate-100 hover:border-slate-200'}`}
                >
                  <FileText className="w-5 h-5" />
                  <span className="font-bold">PDF</span>
                </button>
                <button 
                  onClick={() => setExportFormat('excel')}
                  className={`flex items-center justify-center gap-2 p-4 rounded-2xl border-2 transition-all ${exportFormat === 'excel' ? 'border-emerald-500 bg-emerald-50 text-emerald-700' : 'border-slate-100 hover:border-slate-200'}`}
                >
                  <FileSpreadsheet className="w-5 h-5" />
                  <span className="font-bold">Excel</span>
                </button>
              </div>
            </div>

            <Button 
              className="w-full h-14 rounded-2xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-lg shadow-xl shadow-indigo-200"
              onClick={generateReport}
              disabled={isGenerating}
            >
              {isGenerating ? (
                <div className="flex items-center gap-2">
                  <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  Generating...
                </div>
              ) : (
                <div className="flex items-center gap-2">
                  <Download className="w-6 h-6" />
                  Download {exportFormat.toUpperCase()} Report
                </div>
              )}
            </Button>
          </CardContent>
        </Card>

        <div className="space-y-6">
          <Card className="glass-card border-none bg-gradient-to-br from-slate-800 to-slate-900 text-white p-2">
            <CardContent className="p-6">
              <h3 className="text-lg font-bold mb-4 flex items-center gap-2">
                <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                Report Inclusions
              </h3>
              <ul className="space-y-3 text-sm opacity-80">
                <li className="flex items-start gap-2 italic">
                  <span>•</span> Full breakdown of income vs expenses
                </li>
                <li className="flex items-start gap-2 italic">
                  <span>•</span> Monthly trends and category analysis
                </li>
                <li className="flex items-start gap-2 italic">
                  <span>•</span> Savings rate and surplus calculation
                </li>
                <li className="flex items-start gap-2 italic">
                  <span>•</span> Detailed transaction ledger
                </li>
              </ul>
            </CardContent>
          </Card>

          <div className="p-6 bg-blue-50/50 rounded-3xl border border-blue-100 flex items-start gap-4">
            <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center shrink-0">
              <Download className="w-5 h-5 text-blue-600" />
            </div>
            <div>
              <h4 className="text-sm font-bold text-blue-900">Automation Tip</h4>
              <p className="text-xs text-blue-700 opacity-80 leading-relaxed mt-1">
                You can download these reports at the end of every week to keep a physical record of your financial health. 
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
