/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Plus, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle, 
  DialogTrigger,
  DialogFooter
} from '@/components/ui/dialog';
import { Transaction, TransactionType, BUDGET_CATEGORIES, BANKS, Category } from '../types';
import { format } from 'date-fns';

interface TransactionFormProps {
  onAddTransaction: (transaction: Omit<Transaction, 'id'>) => void;
  householdExpense: number;
  onUpdateHouseholdExpense: (amount: number) => void;
  currencySymbol: string;
  customCategories: (Transaction['category'] | Category)[];
}

export function TransactionForm({ 
  onAddTransaction, 
  householdExpense, 
  onUpdateHouseholdExpense, 
  currencySymbol,
  customCategories = []
}: TransactionFormProps) {
  const [open, setOpen] = useState(false);
  const [type, setType] = useState<TransactionType>('expense');
  const [amount, setAmount] = useState('');
  const [category, setCategory] = useState('');
  const [subCategory, setSubCategory] = useState('');
  const [description, setDescription] = useState('');
  const [date, setDate] = useState(format(new Date(), 'yyyy-MM-dd'));

  const [tempHousehold, setTempHousehold] = useState(householdExpense.toString());
  const [showHouseholdEdit, setShowHouseholdEdit] = useState(false);

  const filteredCategories = React.useMemo(() => {
    const all = [...BUDGET_CATEGORIES, ...((customCategories as any[]).map(c => typeof c === 'string' ? { name: c, group: 'expense', color: '#6366f1' } : c))];
    return all.filter(c => type === 'income' ? c.group === 'income' : c.group !== 'income');
  }, [type, customCategories]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!amount || !category || !date) return;

    onAddTransaction({
      type,
      amount: parseFloat(amount),
      category,
      subCategory: category === 'Credit Card' ? subCategory : undefined,
      description,
      date: new Date(date).toISOString(),
    });

    // Reset form
    setAmount('');
    setCategory('');
    setSubCategory('');
    setDescription('');
    setDate(format(new Date(), 'yyyy-MM-dd'));
    setOpen(false);
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger className="fixed bottom-8 right-8 h-18 w-18 rounded-full shadow-2xl bg-indigo-600 hover:bg-indigo-700 text-white flex items-center justify-center p-0 z-50 transition-all active:scale-95">
        <Plus className="h-10 w-10" />
      </DialogTrigger>
      <DialogContent className="sm:max-w-[425px] rounded-3xl bg-white/90 backdrop-blur-xl border-white/40">
        <DialogHeader>
          <DialogTitle className="text-2xl font-bold text-slate-800">Add Transaction</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-6 py-4">
          <div className="flex gap-2 p-1 bg-slate-100 rounded-xl">
            <Button
              type="button"
              variant={type === 'expense' ? 'secondary' : 'ghost'}
              className={`flex-1 rounded-lg ${type === 'expense' ? 'bg-white shadow-sm text-indigo-600' : 'text-slate-500'}`}
              onClick={() => setType('expense')}
            >
              Expense
            </Button>
            <Button
              type="button"
              variant={type === 'income' ? 'secondary' : 'ghost'}
              className={`flex-1 rounded-lg ${type === 'income' ? 'bg-white shadow-sm text-green-600' : 'text-slate-500'}`}
              onClick={() => setType('income')}
            >
              Income
            </Button>
          </div>

          <div className="p-3 bg-indigo-50 border border-indigo-100 rounded-2xl">
            <div className="flex items-center justify-between mb-2">
              <span className="text-[10px] font-bold text-indigo-600 uppercase tracking-wider">Fixed Household Exp</span>
              <Button 
                type="button" 
                variant="ghost" 
                size="sm" 
                className="h-6 text-[10px] font-bold text-indigo-500 hover:text-indigo-700"
                onClick={() => setShowHouseholdEdit(!showHouseholdEdit)}
              >
                {showHouseholdEdit ? 'Close' : 'Update'}
              </Button>
            </div>
            {showHouseholdEdit ? (
              <div className="flex gap-2">
                <Input 
                  type="number" 
                  value={tempHousehold} 
                  onChange={(e) => setTempHousehold(e.target.value)}
                  className="h-8 text-sm"
                  placeholder="30000"
                />
                <Button 
                  type="button" 
                  size="sm" 
                  className="h-8 bg-indigo-600 text-white"
                  onClick={() => {
                    onUpdateHouseholdExpense(parseFloat(tempHousehold) || 0);
                    setShowHouseholdEdit(false);
                  }}
                >
                  Save
                </Button>
              </div>
            ) : (
              <div className="text-sm font-bold text-slate-700">{currencySymbol}{householdExpense.toLocaleString()}</div>
            )}
          </div>

          <div className="space-y-2">
            <Label htmlFor="amount" className="text-xs font-bold text-slate-500 uppercase">Amount</Label>
            <Input
              id="amount"
              type="number"
              step="0.01"
              placeholder="0.00"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              className="text-lg h-12 rounded-xl bg-white/50 border-white/40"
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="category" className="text-xs font-bold text-slate-500 uppercase">Category</Label>
            <Select value={category} onValueChange={setCategory} required>
              <SelectTrigger id="category" className="h-12 rounded-xl bg-white/50 border-white/40">
                <SelectValue placeholder="Select category" />
              </SelectTrigger>
              <SelectContent className="rounded-xl border-white/40 glass-panel">
                {filteredCategories.map((cat) => (
                  <SelectItem key={cat.name} value={cat.name} className="hover:bg-slate-100 rounded-lg">
                    <div className="flex items-center gap-2">
                      <div className="w-3 h-3 rounded-full" style={{ backgroundColor: cat.color }} />
                      {cat.name}
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {category === 'Credit Card' && (
            <div className="space-y-2 animate-in fade-in slide-in-from-top-2 duration-300">
              <Label htmlFor="bank" className="text-xs font-bold text-slate-500 uppercase">Bank / Provider</Label>
              <Select value={subCategory} onValueChange={setSubCategory} required>
                <SelectTrigger id="bank" className="h-12 rounded-xl bg-white/50 border-white/40">
                  <SelectValue placeholder="Select bank" />
                </SelectTrigger>
                <SelectContent className="rounded-xl border-white/40 glass-panel">
                  {BANKS.map((bank) => (
                    <SelectItem key={bank} value={bank} className="hover:bg-slate-100 rounded-lg">
                      {bank}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          )}

          <div className="space-y-2">
            <Label htmlFor="date" className="text-xs font-bold text-slate-500 uppercase">Date</Label>
            <Input
              id="date"
              type="date"
              value={date}
              onChange={(e) => setDate(e.target.value)}
              className="h-12 rounded-xl bg-white/50 border-white/40"
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="description" className="text-xs font-bold text-slate-500 uppercase">Description (Optional)</Label>
            <Input
              id="description"
              placeholder="What was this for?"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="h-12 rounded-xl bg-white/50 border-white/40"
            />
          </div>

          <DialogFooter>
            <Button type="submit" className="w-full h-12 bg-indigo-600 text-white rounded-xl text-lg font-bold shadow-lg shadow-indigo-200">
              Save Transaction
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
