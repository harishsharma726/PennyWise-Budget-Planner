import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { Transaction, BUDGET_CATEGORIES } from '../types';

interface BudgetPlanProps {
  transactions: Transaction[];
  currencySymbol: string;
  householdExpense: number;
  netSalary: number;
  hideHeader?: boolean;
}

export function BudgetPlan({ transactions, currencySymbol, householdExpense, netSalary, hideHeader }: BudgetPlanProps) {
  const getCategoryTotal = (name: string) => {
    return transactions
      .filter(t => t.category === name)
      .reduce((acc, curr) => acc + curr.amount, 0);
  };

  const totalSalary = netSalary;
  const expenseCategories = ['Rent', 'Electricity', 'Gas', 'Credit Card', 'Insurance (Him)', 'Insurance (Hey)'];
  const savingsCategories = ['Mutual Fund', 'NPS', 'RD', 'Backup'];

  const totalCategorizedExpenses = expenseCategories.reduce((acc, cat) => acc + getCategoryTotal(cat), 0);
  const totalCategorizedSavings = savingsCategories.reduce((acc, cat) => acc + getCategoryTotal(cat), 0);

  const availableAfterFixed = totalSalary - householdExpense;
  const remainingAfterAll = availableAfterFixed - totalCategorizedExpenses - totalCategorizedSavings;

  return (
    <div className={`grid grid-cols-1 md:grid-cols-2 gap-4 ${hideHeader ? 'p-4' : 'gap-8'}`}>
      {/* Monthly Expenses */}
      <Card className={`glass-card overflow-hidden ${hideHeader ? 'shadow-none border-none bg-white/30' : ''}`}>
        <CardHeader className="bg-pink-50/50 border-b border-pink-100/50 p-4">
          <CardTitle className="text-sm font-bold text-pink-700 uppercase tracking-wider flex justify-between items-center">
            <span>Monthly Expenses</span>
            <span className="text-base">{currencySymbol}{totalCategorizedExpenses.toLocaleString()}</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          <div className="divide-y divide-slate-100">
            {expenseCategories.map(catName => {
              const cat = BUDGET_CATEGORIES.find(c => c.name === catName);
              const amount = getCategoryTotal(catName);
              return (
                <div key={catName} className="flex items-center justify-between p-4 hover:bg-slate-50/50 transition-colors">
                  <div className="flex items-center gap-3">
                    <div className="w-2 h-8 rounded-full" style={{ backgroundColor: cat?.color }} />
                    <span className="font-semibold text-slate-700 text-sm">{catName}</span>
                  </div>
                  <span className="font-bold text-slate-800 text-sm">{currencySymbol}{amount.toLocaleString()}</span>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>

      {/* Monthly Savings */}
      <Card className="glass-card overflow-hidden">
        <CardHeader className="bg-emerald-50/50 border-b border-emerald-100/50 p-4">
          <CardTitle className="text-sm font-bold text-emerald-700 uppercase tracking-wider flex justify-between items-center">
            <span>Monthly Savings</span>
            <span className="text-base">{currencySymbol}{totalCategorizedSavings.toLocaleString()}</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          <div className="divide-y divide-slate-100">
            {savingsCategories.map(catName => {
              const cat = BUDGET_CATEGORIES.find(c => c.name === catName);
              const amount = getCategoryTotal(catName);
              return (
                <div key={catName} className="flex items-center justify-between p-4 hover:bg-slate-50/50 transition-colors">
                  <div className="flex items-center gap-3">
                    <div className="w-2 h-8 rounded-full" style={{ backgroundColor: cat?.color }} />
                    <span className="font-semibold text-slate-700 text-sm">{catName}</span>
                  </div>
                  <span className="font-bold text-slate-800 text-sm">{currencySymbol}{amount.toLocaleString()}</span>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>

      {/* Budget Balance Summary */}
      <Card className="glass-card md:col-span-2 overflow-hidden border-indigo-200">
        <CardHeader className="bg-indigo-600 border-b border-indigo-700 p-4">
          <CardTitle className="text-sm font-bold text-white uppercase tracking-wider">
            Budget Balance Summary
          </CardTitle>
        </CardHeader>
        <CardContent className="p-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <span className="text-xs font-bold text-slate-500 uppercase">Fixed Salary</span>
                <span className="font-bold text-slate-800 text-base">{currencySymbol}{Math.round(totalSalary).toLocaleString()}</span>
              </div>
              <div className="flex justify-between items-center text-red-500">
                <span className="text-xs font-bold uppercase">Household Fixed</span>
                <span className="font-bold text-base">-{currencySymbol}{householdExpense.toLocaleString()}</span>
              </div>
              <Separator />
              <div className="flex justify-between items-center text-indigo-600 pt-2 text-lg font-bold">
                <span>Available</span>
                <span>{currencySymbol}{Math.round(availableAfterFixed).toLocaleString()}</span>
              </div>
            </div>

            <div className="space-y-4">
              <div className="flex justify-between items-center text-pink-600">
                <span className="text-xs font-bold uppercase">Total Bills/CC</span>
                <span className="font-bold text-base">-{currencySymbol}{totalCategorizedExpenses.toLocaleString()}</span>
              </div>
              <div className="flex justify-between items-center text-emerald-600">
                <span className="text-xs font-bold uppercase">Total Savings</span>
                <span className="font-bold text-base">-{currencySymbol}{totalCategorizedSavings.toLocaleString()}</span>
              </div>
              <Separator />
              <div className={`flex justify-between items-center pt-2 text-lg font-bold ${remainingAfterAll < 0 ? 'text-red-500' : 'text-slate-800'}`}>
                <span>Net Balance</span>
                <span>{currencySymbol}{Math.round(remainingAfterAll).toLocaleString()}</span>
              </div>
            </div>

            <div className="flex flex-col justify-center items-center p-6 bg-slate-50 rounded-2xl border border-slate-200">
              <p className="text-[10px] font-bold text-slate-500 uppercase mb-4 tracking-widest text-center">Efficiency Score</p>
              <div className="relative w-24 h-24 flex items-center justify-center">
                <svg className="w-full h-full transform -rotate-90" viewBox="0 0 96 96">
                  <circle cx="48" cy="48" r="40" fill="none" stroke="#e2e8f0" strokeWidth="8" />
                  <circle
                    cx="48" cy="48" r="40" fill="none"
                    stroke={remainingAfterAll < 0 ? '#ef4444' : '#4f46e5'}
                    strokeWidth="8"
                    strokeDasharray={251.2}
                    strokeDashoffset={251.2 - (Math.min(100, Math.max(0, (totalCategorizedSavings / (totalSalary || 1)) * 100)) * 251.2 / 100)}
                    strokeLinecap="round"
                    className="transition-all duration-1000"
                  />
                </svg>
                <div className="absolute inset-0 flex flex-col items-center justify-center">
                  <span className="text-sm font-black text-indigo-900">{totalSalary > 0 ? Math.round((totalCategorizedSavings / totalSalary) * 100) : 0}%</span>
                  <span className="text-[8px] font-bold text-indigo-500 uppercase">Saved</span>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
