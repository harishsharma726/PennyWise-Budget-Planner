/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo, useEffect } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Separator } from '@/components/ui/separator';
import { Calculator, IndianRupee } from 'lucide-react';
import { SalaryFormulas } from '../types';

interface TaxCalculatorProps {
  currencySymbol: string;
  formulas: SalaryFormulas;
  totalPackage: number;
  criticalIllness: number;
  exGratia: number;
  onUpdateTotalPackage: (value: number) => void;
  onUpdateDeductions: (field: 'criticalIllness' | 'exGratia', value: number) => void;
}

export function TaxCalculator({ 
  currencySymbol, 
  formulas, 
  totalPackage, 
  criticalIllness, 
  exGratia, 
  onUpdateTotalPackage,
  onUpdateDeductions
}: TaxCalculatorProps) {
  // Always start blank — user must click Calculate to populate fields
  const [ctcInput, setCtcInput] = useState(0);
  const [localCriticalIllness, setLocalCriticalIllness] = useState(0);
  const [localExGratia, setLocalExGratia] = useState(0);
  const [hasCalculated, setHasCalculated] = useState(false);
  const [income, setIncome] = useState({
    basic: 0,
    hra: 0,
    conveyance: 0,
    special: 0,
    pf: 0,
    criticalIllness: 0,
    exGratia: 0, 
  });

  const calculateFromCTC = (ctc: number, ci: number, eg: number) => {
    const basicAnnual = Math.round(ctc * (formulas.basicPct / 100));
    const hraAnnual = Math.round(basicAnnual * (formulas.hraPct / 100));
    const specialAnnual = Math.round(ctc * (formulas.specialAllowancePct / 100));
    const pfAnnual = Math.round(basicAnnual * (formulas.pfPct / 100));
    
    const criticalAnnual = ci * 12;
    const exGratiaAnnual = eg * 12;

    const usedSoFar = basicAnnual + hraAnnual + specialAnnual + pfAnnual + criticalAnnual + exGratiaAnnual;
    const conveyanceAnnual = Math.max(0, ctc - usedSoFar);

    return {
      basic: Math.round(basicAnnual / 12),
      hra: Math.round(hraAnnual / 12),
      conveyance: Math.round(conveyanceAnnual / 12),
      special: Math.round(specialAnnual / 12),
      pf: Math.round(pfAnnual / 12),
      criticalIllness: ci,
      exGratia: eg,
    };
  };

  // Only re-calculate after the user has explicitly clicked Calculate once
  useEffect(() => {
    if (!hasCalculated) return;
    setIncome(calculateFromCTC(ctcInput, localCriticalIllness, localExGratia));
  }, [formulas, hasCalculated]);

  const totals = useMemo(() => {
    // Gross Salary for Tax = Basic + HRA + Conveyance + Special
    const monthlyGross = income.basic + income.hra + income.conveyance + income.special;
    const annualGross = monthlyGross * 12;
    
    const standardDeduction = 75000;
    const chargeableIncome = Math.max(0, annualGross - standardDeduction);

    let tax = 0;
    const slabs = [
      { min: 400000, max: 800000, rate: 0.05 },
      { min: 800000, max: 1200000, rate: 0.10 },
      { min: 1200000, max: 1600000, rate: 0.15 },
      { min: 1600000, max: 2000000, rate: 0.20 },
      { min: 2000000, max: 2400000, rate: 0.25 },
      { min: 2400000, max: Infinity, rate: 0.30 },
    ];

    const slabBreakdown = slabs.map(slab => {
      const taxableInSlab = Math.max(0, Math.min(chargeableIncome, slab.max) - slab.min);
      const taxInSlab = taxableInSlab * slab.rate;
      tax += taxInSlab;
      return { ...slab, taxAmount: taxInSlab };
    });

    const cess = tax * 0.04;
    const totalTaxLiability = tax + cess;
    const monthlyTax = totalTaxLiability / 12;

    const monthlyInHandBeforeTax = monthlyGross - income.pf; 
    const monthlyInHandAfterTax = monthlyInHandBeforeTax - monthlyTax;

    return {
      monthlyGross,
      annualGross,
      chargeableIncome,
      tax,
      cess,
      totalTaxLiability,
      monthlyTax,
      monthlyInHandBeforeTax,
      monthlyInHandAfterTax,
      slabBreakdown
    };
  }, [income]);

  const handleCalculate = () => {
    const result = calculateFromCTC(ctcInput, localCriticalIllness, localExGratia);
    setIncome(result);
    setHasCalculated(true);
    onUpdateTotalPackage(ctcInput);
    onUpdateDeductions('criticalIllness', localCriticalIllness);
    onUpdateDeductions('exGratia', localExGratia);
  };

  const handleCTCChange = (value: string) => {
    setCtcInput(parseFloat(value) || 0);
  };

  return (
    <div className="space-y-6">
      {/* 1. CTC Input Section */}
      <Card className="border-none bg-indigo-600 text-white shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 right-0 p-8 opacity-10">
          <Calculator className="w-48 h-48" />
        </div>
        <CardContent className="p-10 relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-8">
          <div className="space-y-4">
            <Label className="text-xs font-black uppercase tracking-[0.2em] opacity-70">Annual Total Salary Package (Fixed CTC)</Label>
            <div className="flex items-center gap-3">
              <span className="text-4xl font-black">{currencySymbol}</span>
              <Input 
                type="number" 
                value={ctcInput || ''}
                placeholder="0"
                onChange={(e) => handleCTCChange(e.target.value)}
                className="bg-white/10 border-white/20 text-3xl font-black h-12 rounded-2xl w-full md:w-[300px] focus:bg-white/20 transition-all font-mono placeholder:text-white/40"
              />
              <button 
                onClick={handleCalculate}
                className="bg-white hover:bg-slate-50 text-indigo-600 px-6 h-12 rounded-2xl font-black text-sm uppercase tracking-wider transition-all shadow-xl active:scale-95 whitespace-nowrap"
              >
                Calculate
              </button>
            </div>
          </div>
          <div className="flex gap-10">
            <div className="text-right">
              <p className="text-[10px] font-bold uppercase tracking-widest opacity-60 mb-1">Monthly Gross</p>
              <p className="text-2xl font-black">{currencySymbol}{Math.round(totals.monthlyGross).toLocaleString()}</p>
            </div>
            <div className="text-right">
              <p className="text-[10px] font-bold uppercase tracking-widest opacity-60 mb-1">Monthly Net (In-Hand)</p>
              <p className="text-4xl font-black text-emerald-400">{currencySymbol}{Math.round(totals.monthlyInHandAfterTax).toLocaleString()}</p>
            </div>
            <div className="text-right">
              <p className="text-[10px] font-bold uppercase tracking-widest opacity-60 mb-1">Monthly Tax</p>
              <p className="text-2xl font-black text-rose-300">-{currencySymbol}{Math.round(totals.monthlyTax).toLocaleString()}</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* 2. Main Statement Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        {/* Left: Components & Pre-reqs */}
        <div className="lg:col-span-2 space-y-6">
          <Card className="glass-card overflow-hidden">
            <CardHeader className="bg-slate-50 border-b border-slate-100">
              <CardTitle className="text-xs font-black uppercase tracking-widest text-slate-800">Salary Component Breakdown</CardTitle>
            </CardHeader>
            <CardContent className="p-0">
              <table className="w-full text-xs">
                <thead className="bg-slate-50/50 text-[10px] font-bold text-slate-400 uppercase">
                  <tr>
                    <th className="px-6 py-4 text-left">Component</th>
                    <th className="px-6 py-4 text-right">Annual (Calculated)</th>
                    <th className="px-6 py-4 text-right">Monthly</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-50">
                  {[
                    { label: "Basic Salary", key: "basic", pct: formulas.basicPct },
                    { label: `HRA (${formulas.hraPct}% of Basic)`, key: "hra", pct: (formulas.basicPct * formulas.hraPct / 100) },
                    { label: `Special Allowance (${formulas.specialAllowancePct}%)`, key: "special", pct: formulas.specialAllowancePct },
                    { label: "Conveyance (Balancing)", key: "conveyance", pct: null },
                  ].map((item) => (
                    <tr key={item.key}>
                      <td className="px-6 py-4 font-bold text-slate-700">
                        {item.label}
                      </td>
                      <td className="px-6 py-4 text-right text-slate-500 font-mono">
                        {currencySymbol}{Math.round(income[item.key as keyof typeof income] * 12).toLocaleString()}
                      </td>
                      <td className="px-6 py-4 text-right font-black text-slate-800 font-mono">
                        {currencySymbol}{income[item.key as keyof typeof income].toLocaleString()}
                      </td>
                    </tr>
                  ))}
                  <tr className="bg-indigo-50/50 font-black border-t-2 border-indigo-100">
                    <td className="px-6 py-4 uppercase tracking-widest text-indigo-700">Total Gross</td>
                    <td className="px-6 py-4 text-right text-indigo-700 font-mono">{currencySymbol}{Math.round(totals.annualGross).toLocaleString()}</td>
                    <td className="px-6 py-4 text-right text-indigo-700 font-mono">{currencySymbol}{Math.round(totals.monthlyGross).toLocaleString()}</td>
                  </tr>
                </tbody>
              </table>
            </CardContent>
          </Card>

          <Card className="glass-card">
            <CardHeader className="bg-slate-50 border-b border-slate-100">
              <CardTitle className="text-xs font-black uppercase tracking-widest text-slate-800">Deductions & Other Pre-reqs (Editable)</CardTitle>
            </CardHeader>
            <CardContent className="p-6">
             <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                <div className="space-y-3 opacity-50">
                  <Label className="text-[10px] font-black uppercase text-slate-400">PF (Employee)</Label>
                  <p className="text-[10px] text-slate-400 -mt-2">Yearly: {currencySymbol}{(income.pf * 12).toLocaleString()}</p>
                  <Input disabled type="number" value={income.pf} className="h-10 rounded-xl font-bold font-mono bg-slate-50" />
                </div>
                <div className="space-y-3">
                  <Label className="text-[10px] font-black uppercase text-slate-400">Critical Illness</Label>
                  <p className="text-[10px] text-slate-400 -mt-2">Yearly: {currencySymbol}{(localCriticalIllness * 12).toLocaleString()}</p>
                  <Input type="number" value={localCriticalIllness || ''} placeholder="0" onChange={(e) => setLocalCriticalIllness(parseFloat(e.target.value) || 0)} className="h-10 rounded-xl font-bold font-mono" />
                </div>
                <div className="space-y-3">
                  <Label className="text-[10px] font-black uppercase text-slate-400">Monthly Ex-Gratia</Label>
                  <p className="text-[10px] text-slate-400 -mt-2">Yearly: {currencySymbol}{(localExGratia * 12).toLocaleString()}</p>
                  <Input type="number" value={localExGratia || ''} placeholder="0" onChange={(e) => setLocalExGratia(parseFloat(e.target.value) || 0)} className="h-10 rounded-xl font-bold font-mono" />
                </div>
              </div>
            </CardContent>
          </Card>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card className="bg-slate-800 text-white p-6 rounded-3xl flex flex-col justify-center">
              <p className="text-[10px] font-black uppercase tracking-widest opacity-60 mb-2">In-Hand (Before Tax)</p>
              <h3 className="text-3xl font-black">{currencySymbol}{Math.round(totals.monthlyInHandBeforeTax).toLocaleString()}<span className="text-sm opacity-50 ml-2">/ month</span></h3>
            </Card>
            <Card className="bg-emerald-600 text-white p-6 rounded-3xl flex flex-col justify-center shadow-xl shadow-emerald-500/20">
              <p className="text-[10px] font-black uppercase tracking-widest opacity-60 mb-2">In-Hand (After Tax)</p>
              <h3 className="text-3xl font-black">{currencySymbol}{Math.round(totals.monthlyInHandAfterTax).toLocaleString()}<span className="text-sm opacity-50 ml-2">/ month</span></h3>
            </Card>
          </div>
        </div>

        {/* Right: Tax Slabs & Summary */}
        <div className="space-y-6">
          <Card className="glass-card overflow-hidden">
            <CardHeader className="bg-orange-50 border-b border-orange-100">
              <CardTitle className="text-xs font-black uppercase tracking-widest text-orange-800">New Tax Regime Slabs</CardTitle>
            </CardHeader>
            <CardContent className="p-0">
              <table className="w-full text-xs">
                <tbody className="divide-y divide-slate-100">
                  {totals.slabBreakdown.map((slab, i) => (
                    <tr key={i} className={slab.taxAmount > 0 ? "bg-orange-50/20" : ""}>
                      <td className="px-4 py-3 font-medium text-slate-600">
                        {slab.max === Infinity ? `Above ₹${(slab.min/100000).toFixed(0)}L` : `₹${(slab.min/100000).toFixed(0)}L - ₹${(slab.max/100000).toFixed(0)}L`}
                      </td>
                      <td className="px-4 py-3 text-right font-black text-slate-800">
                        {slab.taxAmount > 0 ? `${currencySymbol}${Math.round(slab.taxAmount).toLocaleString()}` : "—"}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </CardContent>
          </Card>

          <Card className="glass-card bg-slate-50 border-slate-200">
            <CardContent className="p-6 space-y-4">
              <div className="flex justify-between items-center">
                <span className="text-[10px] font-bold text-slate-500 uppercase">Standard Deduction</span>
                <span className="text-xs font-bold text-emerald-600">-{currencySymbol}75,000</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-[10px] font-bold text-slate-500 uppercase">Tax on Income</span>
                <span className="text-xs font-bold">{currencySymbol}{Math.round(totals.tax).toLocaleString()}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-[10px] font-bold text-slate-500 uppercase">Cess (4%)</span>
                <span className="text-xs font-bold">{currencySymbol}{Math.round(totals.cess).toLocaleString()}</span>
              </div>
              <Separator />
              <div className="flex justify-between items-center text-slate-900 font-black">
                <span className="text-xs uppercase">Annual Liability</span>
                <span className="text-xl">{currencySymbol}{Math.round(totals.totalTaxLiability).toLocaleString()}</span>
              </div>
            </CardContent>
          </Card>

          <a 
            href="https://www.incometax.gov.in/" 
            target="_blank" 
            className="flex items-center justify-center gap-3 bg-white hover:bg-slate-50 border-2 border-slate-200 text-slate-800 py-4 rounded-3xl text-sm font-black transition-all shadow-sm group"
          >
            File ITR on Official Portal
            <IndianRupee className="w-4 h-4 group-hover:scale-125 transition-transform" />
          </a>
        </div>
      </div>
    </div>
  );
}
