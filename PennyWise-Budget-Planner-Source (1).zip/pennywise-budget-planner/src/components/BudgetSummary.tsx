/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { 
  ArrowUpCircle, 
  ArrowDownCircle, 
  Wallet, 
  ShoppingCart, 
  PiggyBank, 
  CreditCard, 
  MoreVertical,
  Trash2,
  Maximize2,
  Palette,
  Edit2,
  GripHorizontal,
  PieChart as PieChartIcon,
  List as ListIcon,
  Target
} from 'lucide-react';
import { Transaction, DashboardMetric } from '../types';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Button } from '@/components/ui/button';
import {
  DndContext, 
  closestCenter,
  KeyboardSensor,
  PointerSensor,
  useSensor,
  useSensors,
  DragEndEvent
} from '@dnd-kit/core';
import {
  arrayMove,
  SortableContext,
  sortableKeyboardCoordinates,
  rectSortingStrategy,
  useSortable,
} from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';

interface BudgetSummaryProps {
  transactions: Transaction[];
  currencySymbol: string;
  householdExpense: number;
  netSalary: number;
  metrics: DashboardMetric[];
  onUpdateMetric: (metric: DashboardMetric) => void;
  onDeleteMetric: (id: string) => void;
  onReorderMetrics: (metrics: DashboardMetric[]) => void;
  renderRichComponent: (type: DashboardMetric['type']) => React.ReactNode;
}

interface SortableMetricProps {
  key?: string | number;
  metric: DashboardMetric;
  value: number;
  currencySymbol: string;
  isDark: boolean;
  color: { name: string; bg: string; text: string; lightBg: string };
  onUpdateMetric: (metric: DashboardMetric) => void;
  onDeleteMetric: (id: string) => void;
  richComponent?: React.ReactNode;
}

function SortableMetric({ 
  metric, 
  value, 
  currencySymbol, 
  isDark, 
  color, 
  onUpdateMetric, 
  onDeleteMetric,
  richComponent
}: SortableMetricProps) {
  const {
    attributes,
    listeners,
    setNodeRef,
    transform,
    transition,
    isDragging
  } = useSortable({ id: metric.id });

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
    zIndex: isDragging ? 10 : 1,
    opacity: isDragging ? 0.5 : 1,
  };

  const colSpan = {
    sm: 'lg:col-span-3',
    md: 'lg:col-span-6',
    lg: 'lg:col-span-12'
  }[metric.size];

  const handleSizeChange = (e: React.MouseEvent) => {
    e.stopPropagation();
    const nextSize: Record<string, 'sm' | 'md' | 'lg'> = { sm: 'md', md: 'lg', lg: 'sm' };
    onUpdateMetric({ ...metric, size: nextSize[metric.size] });
  };

  const handleColorChange = (e: React.MouseEvent) => {
    e.stopPropagation();
    const colors = [
      { name: 'Emerald', bg: 'bg-emerald-600', text: 'text-white', lightBg: 'bg-emerald-50/10' },
      { name: 'Sky', bg: 'bg-sky-50/10', text: 'text-sky-600', lightBg: 'bg-sky-50/10' },
      { name: 'Indigo', bg: 'bg-indigo-50/10', text: 'text-indigo-600', lightBg: 'bg-indigo-50/10' },
      { name: 'Pink', bg: 'bg-pink-50/10', text: 'text-pink-600', lightBg: 'bg-pink-50/10' },
      { name: 'Rose', bg: 'bg-rose-50/10', text: 'text-rose-600', lightBg: 'bg-rose-50/10' },
      { name: 'Cyan', bg: 'bg-cyan-50/10', text: 'text-cyan-600', lightBg: 'bg-cyan-50/10' },
      { name: 'Slate', bg: 'bg-slate-50/10', text: 'text-slate-600', lightBg: 'bg-slate-50/10' },
      { name: 'Amber', bg: 'bg-amber-50/10', text: 'text-amber-600', lightBg: 'bg-amber-50/10' },
      { name: 'Violet', bg: 'bg-violet-600', text: 'text-white', lightBg: 'bg-violet-50/10' },
      { name: 'Indigo Dark', bg: 'bg-indigo-600', text: 'text-white', lightBg: 'bg-indigo-50/10' },
    ];
    const currentIndex = colors.findIndex(c => c.bg === metric.color || metric.color.includes(c.bg));
    const nextIndex = (currentIndex + 1) % colors.length;
    onUpdateMetric({ ...metric, color: colors[nextIndex].bg });
  };

  const isRich = !!richComponent;

  const getMetricIcon = (iconName: string) => {
    switch (iconName) {
      case 'wallet': return <Wallet className="h-4 w-4 opacity-70" />;
      case 'arrow-up-circle': return <ArrowUpCircle className="h-4 w-4" />;
      case 'shopping-cart': return <ShoppingCart className="h-4 w-4" />;
      case 'credit-card': return <CreditCard className="h-4 w-4" />;
      case 'arrow-down-circle': return <ArrowDownCircle className="h-4 w-4" />;
      case 'piggy-bank': return <PiggyBank className="h-4 w-4" />;
      case 'pie-chart': return <PieChartIcon className="h-4 w-4" />;
      case 'list': return <ListIcon className="h-4 w-4" />;
      case 'target': return <Target className="h-4 w-4" />;
      default: return <Wallet className="h-4 w-4" />;
    }
  };

  return (
    <Card 
      ref={setNodeRef}
      style={style}
      className={`glass-card ${metric.color} ${isDark ? 'text-white border-none shadow-indigo-500/10 shadow-lg' : isRich ? 'bg-white/40 border-white/50 shadow-sm' : 'border-slate-100 shadow-sm'} group relative transition-all hover:shadow-xl ${colSpan} cursor-default overflow-hidden flex flex-col`}
    >
      <div className="pt-4 px-5 flex items-center justify-between shrink-0">
        <div className="flex items-center gap-2">
          <div 
            {...attributes} 
            {...listeners} 
            className={`cursor-grab active:cursor-grabbing p-1.5 rounded-md transition-colors ${isDark ? 'hover:bg-white/10' : 'hover:bg-slate-100'}`}
          >
            <GripHorizontal className={`h-3.5 w-3.5 ${isDark ? 'opacity-50' : 'text-slate-400'}`} />
          </div>
          <p className={`text-[10px] font-black uppercase tracking-widest ${metric.textColor || (isDark ? 'opacity-70' : color.text)}`}>
            {metric.label}
          </p>
        </div>
        <div className="flex items-center gap-1">
          <div className={metric.textColor || (isDark ? 'opacity-70' : color.text)}>
            {getMetricIcon(metric.icon)}
          </div>
          <Popover>
            <PopoverTrigger className={`h-7 w-7 rounded-full opacity-0 group-hover:opacity-100 transition-opacity inline-flex items-center justify-center cursor-pointer outline-none ${isDark ? 'hover:bg-white/20' : 'hover:bg-slate-200'}`}>
              <MoreVertical className="h-3.5 w-3.5" />
            </PopoverTrigger>
            <PopoverContent className="w-48 p-2 rounded-2xl shadow-2xl border-none" align="end">
              <div className="space-y-1">
                <Button variant="ghost" size="sm" className="w-full justify-start text-[11px] font-bold h-9 rounded-xl" onClick={handleSizeChange}>
                  <Maximize2 className="h-3.5 w-3.5 mr-2" /> Resize ({metric.size})
                </Button>
                {!isRich && (
                  <>
                    <Button variant="ghost" size="sm" className="w-full justify-start text-[11px] font-bold h-9 rounded-xl" onClick={handleColorChange}>
                      <Palette className="h-3.5 w-3.5 mr-2" /> Change Color
                    </Button>
                    <Button variant="ghost" size="sm" className="w-full justify-start text-[11px] font-bold h-9 rounded-xl" onClick={(e) => {
                      e.stopPropagation();
                      const textColors = ['', 'text-white', 'text-slate-800', 'text-indigo-600', 'text-rose-600', 'text-emerald-600'];
                      const currentIndex = textColors.indexOf(metric.textColor || '');
                      const nextIndex = (currentIndex + 1) % textColors.length;
                      onUpdateMetric({ ...metric, textColor: textColors[nextIndex] });
                    }}>
                      <Edit2 className="h-3.5 w-3.5 mr-2" /> Font Color
                    </Button>
                  </>
                )}
                <Button variant="ghost" size="sm" className="w-full justify-start text-[11px] font-bold h-9 rounded-xl text-rose-500 hover:text-rose-600 hover:bg-rose-50" onClick={() => onDeleteMetric(metric.id)}>
                  <Trash2 className="h-3.5 w-3.5 mr-2" /> Delete Box
                </Button>
              </div>
            </PopoverContent>
          </Popover>
        </div>
      </div>

      <CardContent className={`px-5 pb-5 pt-2 flex-1 flex flex-col ${isRich ? 'p-0' : ''}`}>
        {isRich ? (
          <div className="flex-1 w-full overflow-hidden rounded-b-2xl">
            {richComponent}
          </div>
        ) : (
          <div className="flex flex-col gap-3">
            <h2 className={`text-2xl font-black tracking-tight ${metric.textColor || (isDark ? 'text-white' : 'text-slate-800')}`}>
              {currencySymbol}{Math.round(value).toLocaleString()}
            </h2>
            <p className={`text-[10px] font-bold uppercase tracking-tight ${metric.textColor || (isDark ? 'opacity-50' : 'text-slate-400')}`}>
              {metric.type === 'total-salary' ? 'Added via Ledger' : 
               metric.type === 'investments' ? 'Wealth Creation' : 
               metric.type === 'total-expense' ? 'Monthly Burn' : 
               'Calculated Status'}
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

export function BudgetSummary({ 
  transactions, 
  currencySymbol, 
  householdExpense, 
  netSalary,
  metrics,
  onUpdateMetric,
  onDeleteMetric,
  onReorderMetrics,
  renderRichComponent
}: BudgetSummaryProps) {
  const sensors = useSensors(
    useSensor(PointerSensor),
    useSensor(KeyboardSensor, {
      coordinateGetter: sortableKeyboardCoordinates,
    })
  );

  const salaryAdded = transactions
    .filter(t => t.category === 'Salary')
    .reduce((acc, curr) => acc + curr.amount, 0);

  const otherIncome = transactions
    .filter(t => t.type === 'income' && t.category !== 'Salary')
    .reduce((acc, curr) => acc + curr.amount, 0);

  const bills = transactions
    .filter(t => ['Rent', 'Electricity', 'Gas', 'Insurance (Him)', 'Insurance (Hey)'].includes(t.category))
    .reduce((acc, curr) => acc + curr.amount, 0);

  const ccExpense = transactions
    .filter(t => t.category === 'Credit Card')
    .reduce((acc, curr) => acc + curr.amount, 0);

  const investments = transactions
    .filter(t => ['Mutual Fund', 'NPS', 'RD', 'Backup'].includes(t.category))
    .reduce((acc, curr) => acc + curr.amount, 0);

  const totalIncome = salaryAdded + otherIncome;
  const totalExpense = bills + ccExpense + householdExpense;

  const getMetricValue = (type: DashboardMetric['type']) => {
    switch (type) {
      case 'total-salary': return salaryAdded;
      case 'other-income': return otherIncome;
      case 'total-income': return totalIncome;
      case 'household': return householdExpense;
      case 'cc-expense': return ccExpense;
      case 'total-expense': return totalExpense;
      case 'investments': return investments;
      default: return 0;
    }
  };

  const colors = [
    { name: 'Emerald', bg: 'bg-emerald-600', text: 'text-white', lightBg: 'bg-emerald-50/10' },
    { name: 'Sky', bg: 'bg-sky-50/10', text: 'text-sky-600', lightBg: 'bg-sky-50/10' },
    { name: 'Indigo', bg: 'bg-indigo-50/10', text: 'text-indigo-600', lightBg: 'bg-indigo-50/10' },
    { name: 'Pink', bg: 'bg-pink-50/10', text: 'text-pink-600', lightBg: 'bg-pink-50/10' },
    { name: 'Rose', bg: 'bg-rose-50/10', text: 'text-rose-600', lightBg: 'bg-rose-50/10' },
    { name: 'Cyan', bg: 'bg-cyan-50/10', text: 'text-cyan-600', lightBg: 'bg-cyan-50/10' },
    { name: 'Slate', bg: 'bg-slate-50/10', text: 'text-slate-600', lightBg: 'bg-slate-50/10' },
    { name: 'Amber', bg: 'bg-amber-50/10', text: 'text-amber-600', lightBg: 'bg-amber-50/10' },
    { name: 'Violet', bg: 'bg-violet-600', text: 'text-white', lightBg: 'bg-violet-50/10' },
    { name: 'Indigo Dark', bg: 'bg-indigo-600', text: 'text-white', lightBg: 'bg-indigo-50/10' },
  ];

  const handleDragEnd = (event: DragEndEvent) => {
    const { active, over } = event;

    if (over && active.id !== over.id) {
      const oldIndex = metrics.findIndex(m => m.id === active.id);
      const newIndex = metrics.findIndex(m => m.id === over.id);
      onReorderMetrics(arrayMove(metrics, oldIndex, newIndex));
    }
  };

  return (
    <DndContext 
      sensors={sensors}
      collisionDetection={closestCenter}
      onDragEnd={handleDragEnd}
    >
      <SortableContext 
        items={metrics.map(m => m.id)}
        strategy={rectSortingStrategy}
      >
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-4 mb-8">
          {metrics.map((metric) => {
            const value = getMetricValue(metric.type);
            const color = colors.find(c => metric.color.includes(c.bg)) || colors[0];
            const isDark = metric.color.includes('600');
            
            return (
              <SortableMetric 
                key={metric.id}
                metric={metric}
                value={value}
                currencySymbol={currencySymbol}
                isDark={isDark}
                color={color}
                onUpdateMetric={onUpdateMetric}
                onDeleteMetric={onDeleteMetric}
                richComponent={renderRichComponent(metric.type)}
              />
            );
          })}
        </div>
      </SortableContext>
    </DndContext>
  );
}

