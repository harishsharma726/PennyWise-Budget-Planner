/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useMemo } from 'react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer, 
  PieChart, 
  Pie, 
  Cell,
  Legend
} from 'recharts';
import { Transaction, BUDGET_CATEGORIES } from '../types';
import { format, parseISO, startOfMonth, subMonths, isSameMonth } from 'date-fns';

interface MonthlyChartsProps {
  transactions: Transaction[];
  currencySymbol: string;
  hideHeader?: boolean;
}

export function MonthlyCharts({ transactions, currencySymbol, hideHeader }: MonthlyChartsProps) {
  const chartData = useMemo(() => {
    const last6Months = Array.from({ length: 6 }, (_, i) => {
      const date = subMonths(new Date(), i);
      return {
        month: format(date, 'MMM'),
        monthFull: format(date, 'MMMM yyyy'),
        income: 0,
        expense: 0,
        date,
      };
    }).reverse();

    transactions.forEach((t) => {
      const tDate = parseISO(t.date);
      const monthData = last6Months.find((m) => isSameMonth(m.date, tDate));
      if (monthData) {
        if (t.type === 'income') {
          monthData.income += t.amount;
        } else {
          monthData.expense += t.amount;
        }
      }
    });

    return last6Months;
  }, [transactions]);

  const categoryData = useMemo(() => {
    const expenses = transactions.filter((t) => t.type === 'expense');
    const categories: { [key: string]: number } = {};

    expenses.forEach((t) => {
      categories[t.category] = (categories[t.category] || 0) + t.amount;
    });

    return Object.entries(categories).map(([name, value]) => ({
      name,
      value,
      color: BUDGET_CATEGORIES.find((c) => c.name === name)?.color || '#e2e2e2',
    })).sort((a, b) => b.value - a.value);
  }, [transactions]);

  return (
    <div className={`grid grid-cols-1 md:grid-cols-2 gap-4 ${hideHeader ? 'p-0 h-full' : 'mb-8'}`}>
      <div className={`${hideHeader ? 'bg-transparent border-none p-4' : 'bg-white/40 backdrop-blur-md rounded-2xl border border-white p-6'} flex flex-col h-full min-h-[300px]`}>
        {!hideHeader && (
          <div className="flex justify-between items-center mb-6 px-2">
            <h4 className="font-bold text-slate-800">Cash Flow</h4>
            <span className="text-[10px] text-slate-500 font-bold uppercase tracking-widest">Last 6 Months</span>
          </div>
        )}
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={chartData}>
            <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="rgba(255,255,255,0.2)" />
            <XAxis dataKey="month" axisLine={false} tickLine={false} tick={{ fill: '#64748b', fontSize: 10, fontWeight: 600 }} />
            <YAxis axisLine={false} tickLine={false} tick={{ fill: '#64748b', fontSize: 10, fontWeight: 600 }} />
            <Tooltip 
              formatter={(value: number) => [`${currencySymbol}${value.toLocaleString()}`, '']}
              contentStyle={{ backgroundColor: 'rgba(255,255,255,0.8)', backdropFilter: 'blur(10px)', borderRadius: '12px', border: '1px solid rgba(255,255,255,0.4)', boxShadow: '0 4px 12px rgba(0,0,0,0.05)' }} 
              cursor={{ fill: 'rgba(255,255,255,0.1)' }}
            />
            <Bar dataKey="income" name="Income" fill="#BDECB6" radius={[4, 4, 0, 0]} barSize={20} />
            <Bar dataKey="expense" name="Expense" fill="#FFB7B2" radius={[4, 4, 0, 0]} barSize={20} />
          </BarChart>
        </ResponsiveContainer>
      </div>

      <div className={`${hideHeader ? 'bg-transparent border-none p-4' : 'bg-white/40 backdrop-blur-md rounded-2xl border border-white p-6'} flex flex-col h-full min-h-[300px]`}>
        {!hideHeader && <h4 className="font-bold text-slate-800 mb-6 px-2">Expenses by Category</h4>}
        {categoryData.length > 0 ? (
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie
                data={categoryData}
                cx="50%"
                cy="50%"
                innerRadius={60}
                outerRadius={90}
                paddingAngle={5}
                dataKey="value"
              >
                {categoryData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip 
                formatter={(value: number) => [`${currencySymbol}${value.toLocaleString()}`, '']}
                contentStyle={{ backgroundColor: 'rgba(255,255,255,0.8)', backdropFilter: 'blur(10px)', borderRadius: '12px', border: '1px solid rgba(255,255,255,0.4)', boxShadow: '0 4px 12px rgba(0,0,0,0.05)' }}
              />
              <Legend verticalAlign="bottom" height={36} iconType="circle" wrapperStyle={{ fontSize: '10px', fontWeight: 600, color: '#64748b' }}/>
            </PieChart>
          </ResponsiveContainer>
        ) : (
          <div className="flex items-center justify-center h-full text-slate-400 text-sm font-medium">
            No expense data yet
          </div>
        )}
      </div>
    </div>
  );
}
