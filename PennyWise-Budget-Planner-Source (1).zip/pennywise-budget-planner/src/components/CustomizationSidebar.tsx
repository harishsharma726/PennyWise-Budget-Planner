import React, { useState } from 'react';
import { 
  X, 
  Plus, 
  ChevronRight, 
  Settings2, 
  Wallet, 
  ArrowUpCircle, 
  ArrowDownCircle, 
  ShoppingCart, 
  PiggyBank, 
  CreditCard,
  Check
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { DashboardMetric } from '../types';
import { Separator } from '@/components/ui/separator';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

interface CustomizationSidebarProps {
  isOpen: boolean;
  onClose: () => void;
  metrics: DashboardMetric[];
  onAddMetric: (metric: DashboardMetric) => void;
}

const ICON_OPTIONS = [
  { value: 'wallet', label: 'Wallet', icon: Wallet },
  { value: 'arrow-up-circle', label: 'Income', icon: ArrowUpCircle },
  { value: 'arrow-down-circle', label: 'Expense', icon: ArrowDownCircle },
  { value: 'shopping-cart', label: 'Cart', icon: ShoppingCart },
  { value: 'credit-card', label: 'Card', icon: CreditCard },
  { value: 'piggy-bank', label: 'Savings', icon: PiggyBank },
];

const COLOR_OPTIONS = [
  { name: 'Emerald', value: 'bg-emerald-600' },
  { name: 'Sky', value: 'bg-sky-50/10' },
  { name: 'Indigo', value: 'bg-indigo-50/10' },
  { name: 'Pink', value: 'bg-pink-50/10' },
  { name: 'Rose', value: 'bg-rose-50/10' },
  { name: 'Cyan', value: 'bg-cyan-50/10' },
  { name: 'Slate', value: 'bg-slate-50/10' },
  { name: 'Amber', value: 'bg-amber-50/10' },
  { name: 'Violet', value: 'bg-violet-600' },
  { name: 'Indigo Dark', value: 'bg-indigo-600' },
  { name: 'Orange', value: 'bg-orange-500' },
  { name: 'Teal', value: 'bg-teal-500' },
];

const TEXT_COLOR_OPTIONS = [
  { name: 'Default', value: '' },
  { name: 'White', value: 'text-white' },
  { name: 'Slate', value: 'text-slate-800' },
  { name: 'Indigo', value: 'text-indigo-600' },
  { name: 'Rose', value: 'text-rose-600' },
  { name: 'Emerald', value: 'text-emerald-600' },
];

const TYPE_OPTIONS = [
  { value: 'total-salary', label: 'Total Salary' },
  { value: 'other-income', label: 'Other Income' },
  { value: 'total-income', label: 'Total Income' },
  { value: 'household', label: 'Household Expense' },
  { value: 'cc-expense', label: 'Credit Card Expense' },
  { value: 'total-expense', label: 'Total Expense' },
  { value: 'investments', label: 'Investments & Savings' },
];

export function CustomizationSidebar({ isOpen, onClose, metrics, onAddMetric }: CustomizationSidebarProps) {
  const [newMetric, setNewMetric] = useState({
    label: '',
    type: 'total-income' as DashboardMetric['type'],
    color: 'bg-emerald-600',
    textColor: '',
    size: 'md' as 'sm' | 'md' | 'lg',
    icon: 'wallet'
  });

  const handleAdd = () => {
    if (!newMetric.label) return;
    onAddMetric({
      ...newMetric,
      id: `m-${Date.now()}`
    });
    setNewMetric({
      label: '',
      type: 'total-income',
      color: 'bg-emerald-600',
      textColor: '',
      size: 'md',
      icon: 'wallet'
    });
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-y-0 right-0 w-80 bg-white border-l shadow-2xl z-50 animate-in slide-in-from-right duration-300">
      <div className="flex flex-col h-full">
        {/* Header */}
        <div className="p-4 border-b flex items-center justify-between bg-slate-50">
          <div className="flex items-center gap-2">
            <Settings2 className="h-5 w-5 text-indigo-600" />
            <h2 className="font-black text-slate-800 uppercase tracking-tight">Customize</h2>
          </div>
          <Button variant="ghost" size="icon" onClick={onClose} className="rounded-full hover:bg-slate-200">
            <X className="h-4 w-4" />
          </Button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-6 space-y-8">
          <div className="space-y-4">
            <h3 className="text-xs font-black uppercase text-slate-400 tracking-widest">Add New Dashboard Box</h3>
            
            <div className="space-y-4">
              <div className="space-y-2">
                <Label className="text-xs font-bold uppercase text-slate-500">Box Label</Label>
                <Input 
                  placeholder="e.g. Total Wealth" 
                  value={newMetric.label}
                  onChange={(e) => setNewMetric({ ...newMetric, label: e.target.value })}
                  className="rounded-xl border-slate-200 h-10"
                />
              </div>

              <div className="space-y-2">
                <Label className="text-xs font-bold uppercase text-slate-500">Data Source (Formula)</Label>
                <Select value={newMetric.type} onValueChange={(val: any) => setNewMetric({ ...newMetric, type: val })}>
                  <SelectTrigger className="rounded-xl border-slate-200 h-10">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {TYPE_OPTIONS.map(opt => (
                      <SelectItem key={opt.value} value={opt.value}>{opt.label}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label className="text-xs font-bold uppercase text-slate-500">Icon</Label>
                <div className="grid grid-cols-6 gap-2">
                  {ICON_OPTIONS.map(opt => (
                    <Button 
                      key={opt.value}
                      variant="ghost"
                      size="icon"
                      onClick={() => setNewMetric({ ...newMetric, icon: opt.value })}
                      className={`h-9 w-9 rounded-lg border flex items-center justify-center transition-all ${
                        newMetric.icon === opt.value ? 'border-indigo-600 bg-indigo-50 text-indigo-600' : 'border-slate-100'
                      }`}
                    >
                      <opt.icon className="h-4 w-4" />
                    </Button>
                  ))}
                </div>
              </div>

              <div className="space-y-2">
                <Label className="text-xs font-bold uppercase text-slate-500">Box Color</Label>
                <div className="grid grid-cols-4 gap-2">
                  {COLOR_OPTIONS.map(opt => (
                    <button 
                      key={opt.value}
                      onClick={() => setNewMetric({ ...newMetric, color: opt.value })}
                      className={`h-7 rounded-lg border relative group transition-all ${opt.value} ${
                        newMetric.color === opt.value ? 'ring-2 ring-indigo-600 ring-offset-2' : 'border-slate-100'
                      }`}
                    >
                      {newMetric.color === opt.value && <Check className={`absolute inset-0 m-auto h-3 w-3 ${opt.value.includes('600') || opt.value.includes('500') ? 'text-white' : 'text-indigo-600'}`} />}
                    </button>
                  ))}
                </div>
              </div>

              <div className="space-y-2">
                <Label className="text-xs font-bold uppercase text-slate-500">Text Color</Label>
                <div className="flex flex-wrap gap-2">
                  {TEXT_COLOR_OPTIONS.map(opt => (
                    <Button 
                      key={opt.value}
                      variant="ghost"
                      size="sm"
                      onClick={() => setNewMetric({ ...newMetric, textColor: opt.value })}
                      className={`h-7 px-2 rounded-lg border text-[10px] font-bold ${
                        newMetric.textColor === opt.value ? 'border-indigo-600 bg-indigo-50 text-indigo-600' : 'border-slate-100'
                      }`}
                    >
                      {opt.name}
                    </Button>
                  ))}
                </div>
              </div>

              <div className="space-y-2">
                <Label className="text-xs font-bold uppercase text-slate-500">Box Size</Label>
                <div className="grid grid-cols-3 gap-2">
                  {(['sm', 'md', 'lg'] as const).map(s => (
                    <Button 
                      key={s}
                      variant="ghost"
                      size="sm"
                      onClick={() => setNewMetric({ ...newMetric, size: s })}
                      className={`rounded-lg border text-[10px] font-black uppercase tracking-widest h-8 ${
                        newMetric.size === s ? 'border-indigo-600 bg-indigo-50 text-indigo-600' : 'border-slate-100 hover:bg-slate-50'
                      }`}
                    >
                      {s}
                    </Button>
                  ))}
                </div>
              </div>

              <Button 
                onClick={handleAdd}
                disabled={!newMetric.label}
                className="w-full h-12 bg-indigo-600 hover:bg-indigo-700 text-white rounded-2xl font-black uppercase tracking-tight shadow-lg disabled:opacity-50"
              >
                <Plus className="h-4 w-4 mr-2" /> Add to Dashboard
              </Button>
            </div>
          </div>

          <Separator />

          <div className="space-y-4">
            <h3 className="text-xs font-black uppercase text-slate-400 tracking-widest">Global Page Options</h3>
            <div className="space-y-3">
              <div className="flex items-center justify-between p-3 rounded-2xl bg-slate-50 border border-slate-100 cursor-not-allowed opacity-60">
                <div>
                  <p className="text-xs font-black text-slate-700 uppercase">Interactive Mode</p>
                  <p className="text-[10px] text-slate-500">Enable real-time drag/drop</p>
                </div>
                <div className="w-10 h-6 bg-slate-200 rounded-full" />
              </div>
              <div className="flex items-center justify-between p-3 rounded-2xl bg-slate-50 border border-slate-100 cursor-not-allowed opacity-60">
                <div>
                  <p className="text-xs font-black text-slate-700 uppercase">Glassmorphism</p>
                  <p className="text-[10px] text-slate-500">Enhanced frosted effect</p>
                </div>
                <div className="w-10 h-6 bg-emerald-500 rounded-full flex items-center justify-end px-1">
                  <div className="w-4 h-4 bg-white rounded-full" />
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 bg-slate-50 border-t">
          <p className="text-[10px] text-slate-400 font-medium text-center italic">
            Dashboard layout is automatically saved to your local browser storage.
          </p>
        </div>
      </div>
    </div>
  );
}
