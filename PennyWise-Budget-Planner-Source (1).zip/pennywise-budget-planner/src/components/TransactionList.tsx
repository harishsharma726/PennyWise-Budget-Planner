/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { format, parseISO } from 'date-fns';
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from '@/components/ui/table';
import { Transaction, BUDGET_CATEGORIES } from '../types';
import { Trash2 } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface TransactionListProps {
  transactions: Transaction[];
  onDeleteTransaction: (id: string) => void;
  currencySymbol: string;
  limit?: number;
  hideHeader?: boolean;
}

export function TransactionList({ transactions, onDeleteTransaction, currencySymbol, limit, hideHeader }: TransactionListProps) {
  let sortedTransactions = [...transactions].sort((a, b) => 
    new Date(b.date).getTime() - new Date(a.date).getTime()
  );

  if (limit) {
    sortedTransactions = sortedTransactions.slice(0, limit);
  }

  return (
    <div className={`bg-transparent ${hideHeader ? 'p-0' : 'bg-white/25 backdrop-blur-xl rounded-3xl p-8 border border-white/40 shadow-xl'} overflow-hidden h-full flex flex-col`}>
      {!hideHeader && (
        <div className="flex items-center justify-between mb-8">
          <h3 className="text-xl font-black text-slate-800 tracking-tight">
            {limit ? 'Recent Transactions' : 'Transaction Ledger'}
          </h3>
          {limit && (
            <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest bg-slate-100 px-3 py-1 rounded-full">
              Top {limit} Items
            </span>
          )}
        </div>
      )}
      <div className="overflow-x-auto flex-1 custom-scrollbar">
        <Table>
          <TableHeader>
            <TableRow className="hover:bg-transparent border-white/20">
              <TableHead className="text-[10px] uppercase text-slate-500 font-bold">Date</TableHead>
              <TableHead className="text-[10px] uppercase text-slate-500 font-bold">Category</TableHead>
              <TableHead className="text-[10px] uppercase text-slate-500 font-bold">Description</TableHead>
              <TableHead className="text-[10px] uppercase text-slate-500 font-bold text-right">Amount</TableHead>
              <TableHead className="w-[50px]"></TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {sortedTransactions.length > 0 ? (
              sortedTransactions.map((t) => {
                const category = BUDGET_CATEGORIES.find(c => c.name === t.category);
                return (
                  <TableRow key={t.id} className="hover:bg-white/20 border-white/10 group transition-colors">
                    <TableCell className="text-slate-600 py-4">
                      {format(parseISO(t.date), 'MMM dd, yyyy')}
                    </TableCell>
                    <TableCell>
                      <span className="px-2 py-1 rounded-lg text-[10px] font-bold" style={{ backgroundColor: `${category?.color}33`, color: category?.color }}>
                        {t.category}
                        {t.subCategory && <span className="opacity-60 ml-1">· {t.subCategory}</span>}
                      </span>
                    </TableCell>
                    <TableCell className="text-slate-700 font-medium py-4">
                      {t.description || '-'}
                    </TableCell>
                    <TableCell className={`text-right font-bold py-4 ${t.type === 'income' ? 'text-green-600' : 'text-pink-600'}`}>
                      {t.type === 'income' ? '+' : '-'}{currencySymbol}{t.amount.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                    </TableCell>
                    <TableCell className="py-4">
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-8 w-8 text-slate-400 hover:text-red-400 opacity-0 group-hover:opacity-100 transition-opacity"
                        onClick={() => onDeleteTransaction(t.id)}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </TableCell>
                  </TableRow>
                );
              })
            ) : (
              <TableRow>
                <TableCell colSpan={5} className="h-32 text-center text-slate-500">
                  No transactions yet. Click the + button to add one!
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}
